package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.shiptransfer.portal.core.U.*;

/** routes/records.py - searchable certificate list, CSV export, admin audit log. */
@RestController
public class RecordsController {
    private final Core c; private final Db db;
    public RecordsController(Core c) { this.c = c; this.db = c.db; }

    private List<Row> recordRows(HttpServletRequest req) {
        List<Row> rows = c.certList(c.need(), ""); String t = s(req.getParameter("q")).toLowerCase(), st = s(req.getParameter("status"));
        List<Row> out = new ArrayList<>();
        for (Row r : rows) {
            String hay = String.join(" ", r.s("certificate_number"), r.s("ship_name"), r.s("insured"), r.s("policy_number"), r.s("broker")).toLowerCase();
            if ((st.isEmpty() || r.s("status").equals(st)) && (t.isEmpty() || hay.contains(t))) out.add(r);
        }
        return out;
    }

    /** GET /api/records : search + filter */
    @GetMapping("/api/records")
    public Object records(HttpServletRequest req) { return recordRows(req); }

    private static String csv(Object v) {
        String t = v == null ? "" : v instanceof Double d ? fnum(d) : v.toString();
        return t.contains(",") || t.contains("\"") || t.contains("\n") || t.contains("\r") ? "\"" + t.replace("\"", "\"\"") + "\"" : t;
    }

    /** GET /api/records.csv : CSV export */
    @GetMapping("/api/records.csv")
    public ResponseEntity<byte[]> recordsCsv(HttpServletRequest req) {
        String[] cols = {"certificate_number", "policy_number", "ship_name", "insured", "broker", "from_location", "to_location", "valid_from", "valid_to", "sum_insured", "status"};
        StringBuilder sb = new StringBuilder(String.join(",", cols)).append("\r\n");
        for (Row r : recordRows(req)) { List<String> cells = new ArrayList<>(); for (String k : cols) cells.add(csv(r.get(k))); sb.append(String.join(",", cells)).append("\r\n"); }
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("text/csv"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"records.csv\"").body(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    /** GET /api/audit : admin: who did what and when */
    @GetMapping("/api/audit")
    public Object audit() {
        c.need("admin");
        return db.q("SELECT a.time, COALESCE(u.name,'-') user, a.action, a.target FROM audit a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200");
    }
}
