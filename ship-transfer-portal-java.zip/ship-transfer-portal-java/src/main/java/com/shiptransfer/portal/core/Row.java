package com.shiptransfer.portal.core;

import java.util.LinkedHashMap;

/** One database row (like a Python dict) with small typed getters. */
public class Row extends LinkedHashMap<String, Object> {
    public String str(String k) { Object v = get(k); return v == null ? null : v.toString(); }
    public String s(String k) { Object v = get(k); return v == null ? "" : v.toString(); }
    public Long lng(String k) { Object v = get(k); return v instanceof Number n ? n.longValue() : null; }
    public long l(String k) { Long v = lng(k); return v == null ? 0 : v; }
    public int i(String k) { return (int) l(k); }
    public double dbl(String k) { Object v = get(k); return v instanceof Number n ? n.doubleValue() : 0.0; }
    public Double dblOrNull(String k) { Object v = get(k); return v instanceof Number n ? n.doubleValue() : null; }
    public boolean truthy(String k) { Object v = get(k); return v != null && !(v instanceof Number n && n.doubleValue() == 0) && !v.toString().isEmpty(); }
}
