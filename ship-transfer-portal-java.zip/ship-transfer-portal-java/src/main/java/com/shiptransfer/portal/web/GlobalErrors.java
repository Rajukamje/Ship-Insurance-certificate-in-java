package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.ApiException;
import com.shiptransfer.portal.core.U;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.util.Map;

@RestControllerAdvice
public class GlobalErrors {
    @ExceptionHandler(ApiException.class)
    public ResponseEntity<Map<String, Object>> api(ApiException e) { return ResponseEntity.status(e.status).body(e.body); }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, Object>> tooBig(MaxUploadSizeExceededException e) { return ResponseEntity.status(413).body(U.m("error", "File too large (maximum 8 MB)")); }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> badJson(HttpMessageNotReadableException e) { return ResponseEntity.badRequest().body(U.m("error", "Invalid request body")); }
}
