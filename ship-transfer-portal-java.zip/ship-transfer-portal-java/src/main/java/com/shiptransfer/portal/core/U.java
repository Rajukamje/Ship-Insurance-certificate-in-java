package com.shiptransfer.portal.core;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/** Small helpers. */
public final class U {
    private U() { }

    /** Ordered map that allows null values (use instead of Map.of). */
    public static Map<String, Object> m(Object... kv) {
        Map<String, Object> r = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) r.put((String) kv[i], kv[i + 1]);
        return r;
    }
    public static String s(Object o) { return o == null ? "" : o.toString(); }
    public static String strip(Object o) { return s(o).strip(); }
    public static boolean truthy(Object o) {
        if (o == null) return false;
        if (o instanceof Boolean b) return b;
        if (o instanceof Number n) return n.doubleValue() != 0;
        return !o.toString().isEmpty();
    }
    public static Integer toInt(Object o) {
        if (o instanceof Number n) return n.intValue();
        if (o instanceof String t) { try { return Integer.parseInt(t.strip()); } catch (NumberFormatException e) { return null; } }
        return null;
    }
    public static Long toLong(Object o) { Integer i = toInt(o); return i == null ? null : Long.valueOf(i); }
    public static Double toDouble(Object o) {
        Double d = null;
        if (o instanceof Number n) d = n.doubleValue();
        else if (o instanceof String t) { try { d = Double.parseDouble(t.strip()); } catch (NumberFormatException e) { return null; } }
        return d == null || d.isNaN() || d.isInfinite() ? null : d;
    }
    public static double round(double x, int places) { return new BigDecimal(x).setScale(places, RoundingMode.HALF_EVEN).doubleValue(); }
    public static String usd0(double x) { return String.format(Locale.US, "%,.0f", x); }
    public static String usd2(double x) { return String.format(Locale.US, "%,.2f", x); }
    public static String pad6(long n) { return String.format("%06d", n); }
    public static Object[] cat(Object[] a, Object... b) { Object[] r = Arrays.copyOf(a, a.length + b.length); System.arraycopy(b, 0, r, a.length, b.length); return r; }
    /** Number as Python would print a float (12500000.0). */
    public static String fnum(Double d) {
        if (d == null) return "";
        if (d == Math.floor(d) && Math.abs(d) < 1e15) return (long) d.doubleValue() + ".0";
        return BigDecimal.valueOf(d).toPlainString();
    }
    public static Map<String, Object> body(Map<String, Object> d) { return d == null ? new HashMap<>() : d; }
}
