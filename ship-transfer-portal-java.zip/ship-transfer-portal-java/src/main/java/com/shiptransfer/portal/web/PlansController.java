package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/plans.py - Insurance plans: public list, premium quote calculator, admin add / edit. */
@RestController
public class PlansController {
    private final Core c; private final Db db;
    public PlansController(Core c) { this.c = c; this.db = c.db; }

    /** GET /api/plans : PUBLIC list of plans (admin can add ?all=1 to also see inactive plans) */
    @GetMapping("/api/plans")
    public Object plans(HttpServletRequest req) {
        Row u = c.current(); boolean every = u != null && u.str("role").equals("admin") && !s(req.getParameter("all")).isEmpty();
        return db.q("SELECT * FROM plans" + (every ? "" : " WHERE active=1") + " ORDER BY id");
    }

    /** POST /api/quote : premium calculation with the full breakdown */
    @PostMapping("/api/quote")
    public Object quote(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row plan = db.one("SELECT * FROM plans WHERE id=?", toInt(d.get("plan_id")));
        if (plan == null) throw bad("Choose a plan");
        Double si = toDouble(d.get("sum_insured")); Integer yb = d.get("year_built") == null || s(d.get("year_built")).isEmpty() ? Integer.valueOf(0) : toInt(d.get("year_built"));
        if (si == null || yb == null) throw bad("Sum insured and year built must be numbers");
        if (si <= 0) throw bad("Sum insured must be above zero");
        if (yb != 0 && !(yb >= 1900 && yb <= today().getYear())) throw bad("Enter a real year built");
        Row u = c.current(); Long cid = null;
        if (u != null && u.str("role").equals("client")) cid = c.ids(u)[0];
        else if (u != null && toLong(d.get("client_id")) != null && toLong(d.get("client_id")) != 0 && c.clientOk(u, toLong(d.get("client_id")))) cid = toLong(d.get("client_id"));
        Map<String, Object> out = c.quote(plan, si, yb, truthy(d.get("war_strikes")), truthy(d.get("bbb")), cid); out.put("plan", plan.get("name"));
        return out;
    }

    /** POST /api/plans : admin adds a plan */
    @PostMapping("/api/plans")
    public Object add(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); c.need("admin");
        Double rate = toDouble(d.get("rate")), ded = toDouble(d.get("deductible"));
        if (rate == null || ded == null) throw bad("Rate and deductible must be numbers");
        if (!truthy(d.get("name")) || !truthy(d.get("category")) || !(rate > 0 && rate <= 10) || ded < 0) throw bad("Name, category, rate (0-10 %) and deductible are required");
        db.run("INSERT INTO plans(name,category,description,covers,rate,deductible) VALUES(?,?,?,?,?,?)", s(d.get("name")), s(d.get("category")), s(d.get("description")), s(d.get("covers")), rate, ded);
        c.audit("add plan", s(d.get("name"))); return m("ok", true);
    }

    /** PUT /api/plans/{pid} : admin changes rate, deductible or switches a plan on / off */
    @PutMapping("/api/plans/{pid}")
    public Object edit(@PathVariable long pid, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); c.need("admin"); Row p = db.one("SELECT * FROM plans WHERE id=?", pid);
        if (p == null) throw new ApiException(404, "Plan not found");
        Double rate = toDouble(d.getOrDefault("rate", p.get("rate"))), ded = toDouble(d.getOrDefault("deductible", p.get("deductible")));
        Integer active = toInt(d.containsKey("active") ? (d.get("active") instanceof Boolean b ? (b ? 1 : 0) : d.get("active")) : p.get("active"));
        if (rate == null || ded == null || active == null) throw bad("Rate and deductible must be numbers");
        if (!(rate > 0 && rate <= 10) || ded < 0) throw bad("Rate must be 0-10 % and deductible 0 or more");
        db.run("UPDATE plans SET rate=?, deductible=?, active=? WHERE id=?", rate, ded, active, pid);
        c.audit("edit plan", String.valueOf(pid)); return m("ok", true);
    }
}
