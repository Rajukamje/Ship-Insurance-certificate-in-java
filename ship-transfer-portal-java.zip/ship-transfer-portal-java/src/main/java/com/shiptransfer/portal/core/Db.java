package com.shiptransfer.portal.core;

import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.*;
import java.util.List;

/** Database access: q() = list of rows, one() = first row or null, run() = insert/update (returns the new id). */
@Component
public class Db {
    private final JdbcTemplate jt;
    public Db(DataSource ds) { jt = new JdbcTemplate(ds); }

    public synchronized List<Row> q(String sql, Object... args) {
        return jt.query(sql, (rs, n) -> {
            Row r = new Row(); ResultSetMetaData md = rs.getMetaData();
            for (int i = 1; i <= md.getColumnCount(); i++) r.put(md.getColumnLabel(i), rs.getObject(i));
            return r;
        }, args);
    }

    public Row one(String sql, Object... args) { List<Row> r = q(sql, args); return r.isEmpty() ? null : r.get(0); }
    public boolean exists(String sql, Object... args) { return one(sql, args) != null; }
    public long count(String sql, Object... args) { Row r = one(sql, args); return r == null ? 0 : r.l("n"); }

    public synchronized long run(String sql, Object... args) {
        return jt.execute((ConnectionCallback<Long>) con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
                ps.executeUpdate();
            }
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT last_insert_rowid()")) { return rs.next() ? rs.getLong(1) : 0L; }
        });
    }

    public synchronized void script(String sql) {
        jt.execute((ConnectionCallback<Void>) con -> { try (Statement st = con.createStatement()) { for (String part : sql.split(";\\s*\\n")) if (!part.isBlank()) st.execute(part); } return null; });
    }
}
