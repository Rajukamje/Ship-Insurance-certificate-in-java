package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import com.shiptransfer.portal.service.PdfService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/certificates.py - request, approve + issue (PDF + QR), cancel, download, email, public verify, renew. */
@RestController
public class CertificatesController {
    private final Core c; private final Db db; private final PdfService pdf;
    public CertificatesController(Core c, PdfService pdf) { this.c = c; this.db = c.db; this.pdf = pdf; }

    /** GET /api/certificates : certificates this role may see */
    @GetMapping("/api/certificates")
    public Object certificates() { return c.certList(c.need(), ""); }

    /** POST /api/certificates : request a certificate (Submitted) */
    @PostMapping("/api/certificates")
    public Object request(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row u = c.need(); Core.Scope sc = c.scope(u);
        Row p = db.one("SELECT p.* FROM policies p WHERE p.id=? AND " + sc.sql(), cat(new Object[]{toInt(d.get("policy_id"))}, sc.args()));
        if (p == null) throw bad("Choose one of your policies");
        LocalDate f = pdate(s(d.get("valid_from"))), t = pdate(s(d.get("valid_to")));
        if (f == null || t == null || !t.isAfter(f)) throw bad("Valid-to must be after valid-from");
        if (!truthy(d.get("from_location")) || !truthy(d.get("to_location"))) throw bad("From and To locations are required");
        Double si = toDouble(d.get("sum_insured"));
        if (si == null) throw bad("Sum insured must be a number");
        if (si <= 0) throw bad("Sum insured must be above zero");
        if (p.truthy("sum_insured") && si > p.dbl("sum_insured")) throw bad("Sum insured cannot be more than the policy sum insured");
        long cid = db.run("INSERT INTO certificates(policy_id,from_location,to_location,valid_from,valid_to,mode,sum_insured,status,created_at) VALUES(?,?,?,?,?,?,?,'Submitted',?)",
                p.get("id"), s(d.get("from_location")), s(d.get("to_location")), f.toString(), t.toString(), truthy(d.get("mode")) ? s(d.get("mode")) : "Self-propelled, with cargo on board", si, now());
        Row plan = db.one("SELECT deductible FROM plans WHERE id=?", p.get("plan_id"));
        if (plan != null) db.run("UPDATE certificates SET deductible=? WHERE id=?", plan.get("deductible"), cid);
        for (Long uid : c.adminIds()) c.push(uid, "certificate", "New certificate request #" + cid + " waits for approval.");
        c.audit("request certificate", String.valueOf(cid)); return m("ok", true);
    }

    /** POST /api/certificates/{cid}/issue : admin approves: number + PDF + QR, locked */
    @PostMapping("/api/certificates/{cid}/issue")
    public Object issue(@PathVariable long cid, HttpServletRequest req) {
        Row u = c.need("admin"); Row cert = db.one(CERT_SQL + " WHERE c.id=?", cid);
        if (cert == null || !cert.s("status").equals("Submitted")) throw bad("Only submitted requests can be approved");
        String ps = pstatus(cert.str("pstat"), cert.s("end_date"));
        if (ps.equals("Expired") || ps.equals("Cancelled")) throw bad("Policy is not active, certificate cannot be issued");
        String num = "STC-" + today().getYear() + "-" + pad6(cid);
        db.run("UPDATE certificates SET certificate_number=?, status='Issued', issued_by=?, issued_at=? WHERE id=?", num, u.get("name"), now(), cid);
        cert = db.one(CERT_SQL + " WHERE c.id=?", cid);
        String path = pdf.makeCertificatePdf(cert, ServletUriComponentsBuilder.fromContextPath(req).build().toUriString());
        db.run("UPDATE certificates SET pdf_path=? WHERE id=?", path, cid);                // issued certificates are locked: no edit endpoint exists
        Row cu = db.one("SELECT cl.user_id FROM policies p JOIN clients cl ON cl.id=p.client_id WHERE p.id=?", cert.get("policy_id"));
        c.notify(cu.l("user_id"), "certificate issued", num); c.audit("issue certificate", num);
        return m("ok", true, "number", num);
    }

    /** POST /api/certificates/{cid}/cancel : admin cancels */
    @PostMapping("/api/certificates/{cid}/cancel")
    public Object cancel(@PathVariable long cid) {
        c.need("admin"); db.run("UPDATE certificates SET status='Cancelled' WHERE id=?", cid); c.audit("cancel certificate", String.valueOf(cid)); return m("ok", true);
    }

    private Row ownCert(long cid) {
        List<Row> rows = c.certList(c.need(), "AND c.id=?", cid);
        return !rows.isEmpty() && rows.get(0).truthy("pdf_path") ? rows.get(0) : null;
    }

    /** GET /api/certificates/{cid}/pdf : view or download (?dl=1) the PDF */
    @GetMapping("/api/certificates/{cid}/pdf")
    public ResponseEntity<byte[]> pdf(@PathVariable long cid, @RequestParam(value = "dl", required = false) String dl) throws IOException {
        Row cert = ownCert(cid);
        if (cert == null || !Files.exists(Path.of(cert.s("pdf_path")))) throw new ApiException(404, "Certificate not found or not issued yet");
        c.audit(dl != null && !dl.isEmpty() ? "download" : "view pdf", cert.s("certificate_number"));
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, (dl != null && !dl.isEmpty() ? "attachment" : "inline") + "; filename=\"" + cert.s("certificate_number") + ".pdf\"")
                .body(Files.readAllBytes(Path.of(cert.s("pdf_path"))));
    }

    /** POST /api/certificates/{cid}/email : email the PDF */
    @PostMapping("/api/certificates/{cid}/email")
    public Object email(@PathVariable long cid, @RequestBody(required = false) Map<String, Object> body) {
        Row cert = ownCert(cid); String to = s(body(body).get("to"));
        if (cert == null) throw new ApiException(404, "Certificate not found or not issued yet");
        if (!EMAIL.matcher(to).matches()) throw bad("Enter a valid email address");
        boolean sent = pdf.sendMail(to, "Certificate " + cert.s("certificate_number"), "Please find your marine transfer insurance certificate attached.", cert.s("pdf_path"));
        c.notify(c.current().l("id"), "certificate email", cert.s("certificate_number") + " -> " + to); c.audit("email", cert.s("certificate_number"));
        return m("ok", true, "message", sent ? "Email sent" : "Email logged (set SMTP_HOST to really send)");
    }

    /** GET /api/verify/{num} : PUBLIC: status without private data */
    @GetMapping("/api/verify/{num}")
    public Object verify(@PathVariable String num) {
        Row r = db.one(CERT_SQL + " WHERE c.certificate_number=?", num);
        if (r == null) throw new ApiException(404, "Certificate not found");
        String st = cstatus(r);
        return m("status", st.equals("Issued") ? "Valid" : st, "number", num, "ship", r.get("ship_name"), "imo", r.get("imo"), "from", r.get("from_location"), "to", r.get("to_location"),
                "valid_from", r.get("valid_from"), "valid_to", r.get("valid_to"), "cover", r.get("cover"));
    }

    /** POST /api/certificates/{cid}/renew : renewal request = copy of the old certificate with the next dates (opens 30 days before expiry) */
    @PostMapping("/api/certificates/{cid}/renew")
    public Object renew(@PathVariable long cid) {
        List<Row> rows = c.certList(c.need(), "AND c.id=?", cid);
        if (rows.isEmpty()) throw new ApiException(404, "Certificate not found");
        Row cert = rows.get(0); long left = daysLeft(cert.s("valid_to"));
        if (!cert.s("status").equals("Issued") && !cert.s("status").equals("Expired")) throw bad("Only issued certificates can be renewed");
        if (left > 30) throw bad("Renewal opens 30 days before the certificate expires");
        if (db.exists("SELECT 1 FROM certificates WHERE renewed_from=?", cid)) throw bad("A renewal was already requested");
        String ps = pstatus(cert.str("pstat"), cert.s("end_date"));
        if (ps.equals("Expired") || ps.equals("Cancelled")) throw bad("Renew the policy first");
        LocalDate to = LocalDate.parse(cert.s("valid_to")), from = LocalDate.parse(cert.s("valid_from")), polEnd = LocalDate.parse(cert.s("end_date"));
        long span = java.time.temporal.ChronoUnit.DAYS.between(from, to);
        LocalDate start = to.plusDays(1).isAfter(today()) ? to.plusDays(1) : today(), end = start.plusDays(span).isBefore(polEnd) ? start.plusDays(span) : polEnd;
        if (!end.isAfter(start)) throw bad("The policy ends too soon. Renew the policy first");
        long nw = db.run("INSERT INTO certificates(policy_id,from_location,to_location,valid_from,valid_to,mode,sum_insured,deductible,status,renewed_from,created_at) VALUES(?,?,?,?,?,?,?,?,'Submitted',?,?)",
                cert.get("policy_id"), cert.get("from_location"), cert.get("to_location"), start.toString(), end.toString(), cert.get("mode"), cert.get("sum_insured"), cert.get("deductible"), cid, now());
        for (Long uid : c.adminIds()) c.push(uid, "certificate", "Renewal request #" + nw + " for certificate " + cert.s("certificate_number") + " waits for approval.");
        c.audit("renew certificate", cert.s("certificate_number")); return m("ok", true);
    }
}
