package com.shiptransfer.portal.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.shiptransfer.portal.config.AppProps;
import com.shiptransfer.portal.core.Row;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static com.shiptransfer.portal.core.U.*;

/** pdf_service.py - certificate PDF (with QR code), invoice PDF, email sending. */
@Service
public class PdfService {
    private static final float W = PageSize.A4.getWidth(), H = PageSize.A4.getHeight();
    private static final Color NAVY = new Color(0x0b, 0x2a, 0x5b), GREY = Color.GRAY, BLACK = Color.BLACK, GREEN = new Color(0x14, 0x60, 0x2f);
    private final AppProps props;
    public PdfService(AppProps props) { this.props = props; }

    /** Tiny drawing helper: absolute positions, origin bottom-left (same as reportlab's canvas). */
    private static class Pen {
        final PdfContentByte cb; BaseFont font; float size;
        Pen(PdfContentByte cb) { this.cb = cb; }
        Pen font(String name, float size) {
            try { this.font = BaseFont.createFont(name, BaseFont.WINANSI, false); } catch (Exception e) { throw new IllegalStateException(e); }
            this.size = size; return this;
        }
        Pen color(Color c) { cb.setColorFill(c); return this; }
        void text(float x, float y, String s, int align) {
            cb.beginText(); cb.setFontAndSize(font, size); cb.showTextAligned(align, s == null ? "" : s, x, y, 0); cb.endText();
        }
        void left(float x, float y, String s) { text(x, y, s, PdfContentByte.ALIGN_LEFT); }
        void right(float x, float y, String s) { text(x, y, s, PdfContentByte.ALIGN_RIGHT); }
        void center(float x, float y, String s) { text(x, y, s, PdfContentByte.ALIGN_CENTER); }
        void line(float x1, float y1, float x2, float y2, Color c) { cb.setColorStroke(c); cb.moveTo(x1, y1); cb.lineTo(x2, y2); cb.stroke(); }
        List<String> wrap(String text, float width) {
            List<String> lines = new ArrayList<>(); StringBuilder cur = new StringBuilder();
            for (String w : text.split(" ")) {
                String t = cur.length() == 0 ? w : cur + " " + w;
                if (font.getWidthPoint(t, size) > width && cur.length() > 0) { lines.add(cur.toString()); cur = new StringBuilder(w); } else { cur = new StringBuilder(t); }
            }
            if (cur.length() > 0) lines.add(cur.toString()); return lines;
        }
    }

    private interface Draw { void on(Pen p, PdfContentByte cb); }
    private static void page(OutputStream out, Draw draw) {
        Document doc = new Document(PageSize.A4);
        try { PdfWriter w = PdfWriter.getInstance(doc, out); doc.open(); PdfContentByte cb = w.getDirectContent(); draw.on(new Pen(cb), cb); }
        catch (Exception e) { throw new IllegalStateException("PDF failed", e); }
        finally { if (doc.isOpen()) doc.close(); }
    }

    /** Certificate page, saved in data/pdfs. Returns the file path. */
    public String makeCertificatePdf(Row c, String base) {
        Path path = props.pdfDir.resolve(c.s("certificate_number") + ".pdf");
        try (OutputStream out = Files.newOutputStream(path)) {
            page(out, (p, cb) -> {
                cb.setColorStroke(NAVY); cb.rectangle(25, 25, W - 50, H - 50); cb.stroke();
                p.color(NAVY).font(BaseFont.TIMES_BOLD, 26).left(60, H - 80, "ALLIANZ");
                p.font(BaseFont.HELVETICA, 8).left(60, H - 94, "MARINE INSURANCE (SAMPLE)");
                p.right(W - 60, H - 70, "CERTIFICATE NO."); p.font(BaseFont.HELVETICA_BOLD, 14).right(W - 60, H - 86, c.s("certificate_number"));
                p.font(BaseFont.TIMES_BOLD, 21).center(W / 2, H - 140, "MARINE TRANSFER INSURANCE CERTIFICATE");
                p.font(BaseFont.HELVETICA, 8).center(W / 2, H - 156, "CERTIFICATE OF INSURANCE FOR SHIP TRANSFER");
                String[][][] sections = {
                    {{"POLICY"}, {"Policy number", c.s("policy_number")}, {"Date of issue", c.s("issued_at").substring(0, Math.min(10, c.s("issued_at").length()))}, {"Insured", c.s("insured")},
                        {"Address", c.s("address").isEmpty() ? "-" : c.s("address")}, {"Broker", c.s("broker")}},
                    {{"VESSEL DETAILS"}, {"Name", c.s("ship_name")}, {"IMO number", c.s("imo")}, {"Flag", c.s("flag")}, {"Type", c.s("ship_type")},
                        {"Gross tonnage", String.format(Locale.US, "%,d", c.l("tonnage")) + " GT"}},
                    {{"TRANSFER DETAILS"}, {"From", c.s("from_location")}, {"To", c.s("to_location")}, {"Valid from", c.s("valid_from")}, {"Valid to", c.s("valid_to")}, {"Mode", c.s("mode")}},
                    {{"COVERAGE"}, {"Type of cover", c.s("cover")}, {"Sum insured", "USD " + usd0(c.dbl("sum_insured"))}, {"Deductible", "USD " + usd0(c.dbl("deductible"))}, {"Premium", "USD " + usd0(c.dbl("premium"))}}};
                float y = H - 195;
                for (String[][] sec : sections) {
                    p.color(NAVY).font(BaseFont.HELVETICA_BOLD, 10).left(60, y, sec[0][0]); y -= 15;
                    for (int i = 1; i < sec.length; i++) {
                        p.color(GREY).font(BaseFont.HELVETICA, 9).left(70, y, sec[i][0].toUpperCase());
                        p.color(BLACK).font(BaseFont.HELVETICA_BOLD, 10).left(190, y, sec[i][1]); y -= 14;
                    }
                    y -= 8;
                }
                p.color(NAVY).font(BaseFont.HELVETICA_BOLD, 10).left(60, y, "CLAUSES AND CONDITIONS"); y -= 14;
                String txt = "Subject to the Institute Time Clauses Hulls and the policy wording. Cover applies only while the vessel follows the declared route and remains "
                        + "within class. Towage or deviation requires prior written notice. Claims must be reported without delay. This certificate is subject to the policy terms and does not alter them.";
                p.color(BLACK).font(BaseFont.HELVETICA, 9);
                for (String line : p.wrap(txt, W - 120)) { p.left(60, y, line); y -= 12; }
                p.font(BaseFont.TIMES_ITALIC, 22).left(60, 120, c.s("issued_by")); p.line(60, 112, 280, 112, BLACK);
                p.font(BaseFont.HELVETICA, 8).left(60, 100, "Authorized signature - Underwriting");
                qr(cb, base + "/verify.html?n=" + c.s("certificate_number"), W - 140, 70, 80);
                p.color(BLACK).font(BaseFont.HELVETICA, 7).right(W - 150, 95, "Scan to verify"); p.right(W - 150, 85, c.s("certificate_number"));
                p.color(GREY).center(W / 2, 45, "SAMPLE FOR DEMONSTRATION ONLY. NOT A VALID INSURANCE DOCUMENT. All names and numbers are fictional.");
            });
        } catch (java.io.IOException e) { throw new IllegalStateException(e); }
        return path.toString();
    }

    /** QR code drawn as small squares (size x size points) with its lower-left corner at (x, y). */
    private static void qr(PdfContentByte cb, String url, float x, float y, float size) {
        try {
            BitMatrix bm = new QRCodeWriter().encode(url, BarcodeFormat.QR_CODE, 0, 0, Map.of(EncodeHintType.MARGIN, 0));
            float cell = size / bm.getWidth(); cb.setColorFill(BLACK);
            for (int r = 0; r < bm.getHeight(); r++) for (int col = 0; col < bm.getWidth(); col++)
                if (bm.get(col, r)) cb.rectangle(x + col * cell, y + size - (r + 1) * cell, cell + 0.2f, cell + 0.2f);
            cb.fill();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    /** Invoice PDF (returned as bytes, nothing is stored on disk). */
    public byte[] makeInvoicePdf(Row i) {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        page(buf, (p, cb) -> {
            p.color(NAVY).font(BaseFont.TIMES_BOLD, 26).left(60, H - 80, "ALLIANZ"); p.font(BaseFont.HELVETICA_BOLD, 22).right(W - 60, H - 80, "INVOICE");
            p.color(GREY).font(BaseFont.HELVETICA, 9).left(60, H - 94, "MARINE INSURANCE (SAMPLE)");
            String[][] rows = {{"Invoice number", i.s("invoice_number")}, {"Issue date", i.s("issue_date")}, {"Due date", i.s("due_date")}, {"Status", i.s("status")},
                {"Bill to", i.s("client")}, {"Address", i.s("address").isEmpty() ? "-" : i.s("address")}, {"Policy", i.s("policy_number")}, {"Plan", i.s("plan")}};
            float y = H - 150;
            for (String[] r : rows) {
                p.color(GREY).font(BaseFont.HELVETICA, 9).left(60, y, r[0].toUpperCase());
                p.color(BLACK).font(BaseFont.HELVETICA_BOLD, 11).left(190, y, r[1]); y -= 20;
            }
            p.line(60, y - 5, W - 60, y - 5, NAVY); y -= 30;
            p.font(BaseFont.HELVETICA, 11).left(60, y, i.s("description")); p.font(BaseFont.HELVETICA_BOLD, 14).right(W - 60, y, "USD " + usd2(i.dbl("amount"))); y -= 40;
            p.color(NAVY).font(BaseFont.HELVETICA_BOLD, 16).right(W - 60, y, "TOTAL  USD " + usd2(i.dbl("amount")));
            if (i.truthy("paid_at")) {
                String method = i.truthy("method") ? i.s("method") : "-";
                p.color(GREEN).font(BaseFont.HELVETICA_BOLD, 12).left(60, y, "PAID on " + i.s("paid_at").substring(0, 10) + " (" + method + ")");
            }
            p.color(GREY).font(BaseFont.HELVETICA, 7).center(W / 2, 45, "SAMPLE FOR DEMONSTRATION ONLY. NOT A VALID INSURANCE DOCUMENT. All names and numbers are fictional.");
        });
        return buf.toByteArray();
    }

    /** Send the PDF by email when SMTP_HOST is set (otherwise the caller just logs the email). */
    public boolean sendMail(String to, String subject, String body, String attachPath) {
        String host = System.getenv("SMTP_HOST");
        if (host == null || host.isBlank()) return false;
        try {
            JavaMailSenderImpl s = new JavaMailSenderImpl(); s.setHost(host); s.setPort(Integer.parseInt(Optional.ofNullable(System.getenv("SMTP_PORT")).orElse("587")));
            String user = System.getenv("SMTP_USER");
            Properties pr = s.getJavaMailProperties(); pr.put("mail.smtp.starttls.enable", "true");
            if (user != null && !user.isBlank()) { s.setUsername(user); s.setPassword(Optional.ofNullable(System.getenv("SMTP_PASS")).orElse("")); pr.put("mail.smtp.auth", "true"); }
            MimeMessage m = s.createMimeMessage(); MimeMessageHelper h = new MimeMessageHelper(m, true);
            h.setFrom(Optional.ofNullable(System.getenv("SMTP_FROM")).orElse("noreply@portal.local")); h.setTo(to); h.setSubject(subject); h.setText(body);
            h.addAttachment(Path.of(attachPath).getFileName().toString(), new org.springframework.core.io.FileSystemResource(attachPath), "application/pdf");
            s.send(m); return true;
        } catch (Exception e) { throw new IllegalStateException("Email could not be sent: " + e.getMessage(), e); }
    }
}
