package com.shiptransfer.portal.core;

import com.shiptransfer.portal.config.AppProps;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.List;

import static com.shiptransfer.portal.core.Core.now;
import static com.shiptransfer.portal.core.Core.today;

/** seed.py - creates the tables and adds demo data (users, plans, a policy ...). Also runs the hourly reminder job. */
@Component
public class DbInit {
    public static final BCryptPasswordEncoder PW = new BCryptPasswordEncoder();

    // name, category, description, covers, rate, deductible
    static final List<Object[]> PLANS = List.of(
        new Object[]{"Hull & Machinery - Transit (Ship Transfer)", "Hull", "Delivery or transfer voyage of a vessel from port A to port B, self-propelled or towed.", "Total and partial loss of hull and machinery on the declared route; collision, grounding, fire, heavy weather; salvage and general average. Subject to the Institute Time Clauses Hulls.", 0.39, 50000.0},
        new Object[]{"Hull & Machinery - Annual Cover", "Hull", "Full-year cover for blue-water and brown-water vessels, single ships or fleets.", "Hull, machinery and equipment for a full year; collision liability; sue and labour. Class must be maintained.", 0.55, 75000.0},
        new Object[]{"Cargo ICC (A) - All Risks", "Cargo", "Widest cargo cover for goods in transit by sea, air, road and rail, including incidental storage.", "All risks of physical loss or damage unless excluded (war, delay, inherent vice). Includes theft and pilferage.", 0.56, 5000.0},
        new Object[]{"Cargo ICC (B) - Named Perils", "Cargo", "Mid-range cargo cover for stable goods on familiar routes.", "Named perils only: fire, explosion, stranding, sinking, collision, overturning, earthquake, water damage, total loss overboard.", 0.32, 5000.0},
        new Object[]{"Cargo ICC (C) - Basic Cover", "Cargo", "Lowest-cost cargo cover for low-value or low-risk goods.", "Limited major perils: fire, explosion, stranding, sinking, collision, general average sacrifice.", 0.18, 2500.0},
        new Object[]{"Marine Liability", "Liability", "Third-party liability for ship owners and operators, including marine property.", "Damage to other vessels, ports and property; pollution response; crew injury; legal costs.", 0.25, 25000.0},
        new Object[]{"Builder's Risk", "Builders", "Cover for a vessel while it is being built, converted or repaired in a yard.", "Materials, equipment and vessel under construction; launching; sea trials.", 0.45, 50000.0},
        new Object[]{"Inland Marine - Transit by Road / Rail", "Inland", "Moving or movable property transported over land (trucks, trains, barges).", "Damage during loading, transport and unloading; theft; accident; weather.", 0.2, 2500.0});

    private final Db db; private final AppProps props; private final Core core;
    public DbInit(Db db, AppProps props, Core core) { this.db = db; this.props = props; this.core = core; }

    private long addUser(String name, String email, String pw, String role, String company) {
        return db.run("INSERT INTO users(name,email,phone,password,role,company,address) VALUES(?,?,?,?,?,?,?)",
                name, email, "+65 6000 0000", PW.encode(pw), role, company, "18 Harbour Road, Singapore 049315");
    }

    @PostConstruct
    public void init() throws IOException {
        Files.createDirectories(props.pdfDir); Files.createDirectories(props.upDir);
        db.script(new String(new ClassPathResource("schema.sql").getInputStream().readAllBytes(), StandardCharsets.UTF_8));
        if (!db.exists("SELECT 1 FROM plans"))
            for (Object[] p : PLANS) db.run("INSERT INTO plans(name,category,description,covers,rate,deductible) VALUES(?,?,?,?,?,?)", p);
        if (!db.exists("SELECT 1 FROM users")) seedDemo();
        core.runReminders();                                    // expiry / overdue notifications
    }

    private void seedDemo() {
        LocalDate t = today();
        addUser("Admin User", "admin@portal.com", "Admin@123", "admin", "Portal Admin");
        String[][] bs = {{"Ben Broker", "broker@portal.com", "Oceanic Marine Brokers Ltd.", "Marine"}, {"Maria Cargo", "maria@portal.com", "Harbor Risk Partners", "Cargo"}, {"Tom Tide", "tom@portal.com", "BlueWave Brokers", "Hull"}};
        long[] brokers = new long[3];
        for (int i = 0; i < 3; i++) { long uid = addUser(bs[i][0], bs[i][1], "Broker@123", "broker", bs[i][2]); brokers[i] = db.run("INSERT INTO brokers(user_id,category) VALUES(?,?)", uid, bs[i][3]); }
        long cu = addUser("Chris Client", "client@portal.com", "Client@123", "client", "Northwind Shipping Pte. Ltd.");
        long cid = db.run("INSERT INTO clients(user_id,broker_id,reg_no,country,contact_person) VALUES(?,?,'201912345K','Singapore','Chris Client')", cu, brokers[0]);
        long sid = db.run("INSERT INTO ships(name,imo,flag,type,tonnage,year_built,owner_client_id) VALUES('MV Sea Horizon','9074729','Panama','General cargo',18450,2012,?)", cid);
        long pid = db.run("INSERT INTO policies(policy_number,client_id,broker_id,ship_id,type,premium,start_date,end_date,plan_id,sum_insured) VALUES('MTP-2026-000001',?,?,?,?,?,?,?,1,12500000)",
                cid, brokers[0], sid, PLANS.get(0)[0], 48750.0, t.minusDays(60).toString(), t.plusDays(300).toString());
        db.run("INSERT INTO certificates(policy_id,from_location,to_location,valid_from,valid_to,mode,sum_insured,status,created_at) VALUES(?,?,?,?,?,?,?,'Submitted',?)",
                pid, "Singapore", "Rotterdam, NL", t.plusDays(3).toString(), t.plusDays(36).toString(), "Self-propelled, with cargo on board", 12500000.0, now());
        db.run("INSERT INTO invoices(invoice_number,policy_id,client_id,description,amount,issue_date,due_date) VALUES('INV-2026-000001',?,?,'Premium for policy MTP-2026-000001',48750,?,?)",
                pid, cid, t.toString(), t.plusDays(14).toString());
        // demo reviews from other (fictional) clients so the broker directory is not empty
        Object[][] reviews = {{0, 5, "Fast and clear. Our transfer certificate was ready in one day."}, {0, 4, "Good advice on the right hull plan."}, {1, 5, "Handled our cargo claim without any stress."}, {2, 4, "Knows hull risks very well."}};
        String[] cos = {"Atlas Lines", "Blue Harbour Ltd.", "Orient Freight", "Nordic Tankers"};
        for (int i = 0; i < 4; i++) {
            long u2 = addUser("Demo Client " + (i + 1), "demo" + (i + 1) + "@portal.com", "Client@123", "client", cos[i]);
            long c2 = db.run("INSERT INTO clients(user_id,broker_id) VALUES(?,?)", u2, brokers[(Integer) reviews[i][0]]);
            db.run("INSERT INTO reviews(broker_id,client_id,rating,comment,created_at) VALUES(?,?,?,?,?)", brokers[(Integer) reviews[i][0]], c2, reviews[i][1], reviews[i][2], now());
        }
    }

    /** Repeat every hour while the server runs. */
    @Scheduled(initialDelay = 3600000, fixedDelay = 3600000)
    public void hourly() { core.runReminders(); }
}
