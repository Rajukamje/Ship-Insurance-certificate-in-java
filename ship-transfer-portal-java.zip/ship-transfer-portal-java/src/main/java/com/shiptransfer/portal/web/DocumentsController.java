package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.text.Normalizer;
import java.util.*;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/documents.py - the broker's client file: client information, KYC status and uploaded documents (secure upload + download). */
@RestController
public class DocumentsController {
    /** extension -> first bytes of a real file */
    static final Map<String, byte[]> ALLOWED = new LinkedHashMap<>();
    static {
        ALLOWED.put("pdf", "%PDF".getBytes(StandardCharsets.ISO_8859_1)); ALLOWED.put("png", new byte[]{(byte) 0x89, 'P', 'N', 'G'});
        ALLOWED.put("jpg", new byte[]{(byte) 0xff, (byte) 0xd8}); ALLOWED.put("jpeg", new byte[]{(byte) 0xff, (byte) 0xd8});
        ALLOWED.put("docx", new byte[]{'P', 'K'}); ALLOWED.put("xlsx", new byte[]{'P', 'K'});
    }
    private final Core c; private final Db db;
    public DocumentsController(Core c) { this.c = c; this.db = c.db; }

    /** Status of a required document type: Verified > Pending > Rejected > Missing. */
    public static String best(List<Row> docs, String type) {
        Set<String> st = new HashSet<>(); for (Row d : docs) if (d.s("doc_type").equals(type)) st.add(d.s("status"));
        for (String s : new String[]{"Verified", "Pending", "Rejected"}) if (st.contains(s)) return s;
        return "Missing";
    }

    /** GET /api/clientfile : everything about one client (client sees own file; broker / admin pass ?id=) */
    @GetMapping("/api/clientfile")
    public Object clientfile(@RequestParam(value = "id", required = false) String id) {
        Row u = c.need(); Long cid = u.str("role").equals("client") ? c.ids(u)[0] : toLong(id);
        if (cid == null || !c.clientOk(u, cid)) throw new ApiException(404, "Client not found");
        Row cl = db.one("""
                SELECT cl.*, u.name, u.email, u.phone, u.company, u.address, COALESCE(NULLIF(bu.company,''),bu.name,'Unassigned') broker
                 FROM clients cl JOIN users u ON u.id=cl.user_id LEFT JOIN brokers b ON b.id=cl.broker_id LEFT JOIN users bu ON bu.id=b.user_id WHERE cl.id=?""", cid);
        List<Row> docs = db.q("SELECT id, doc_type, filename, status, note, uploaded_at, policy_id, claim_id FROM documents WHERE client_id=? ORDER BY id DESC", cid);
        List<Row> pols = db.q(POL_SQL + " WHERE p.client_id=? ORDER BY p.id DESC", cid);
        for (Row p : pols) p.put("status", pstatus(p));
        List<Map<String, Object>> required = new ArrayList<>();
        for (String t : REQUIRED_DOCS) required.add(m("type", t, "status", best(docs, t)));
        return m("client", cl, "documents", docs, "required", required, "doc_types", DOC_TYPES, "policies", pols,
                "claims", db.q("SELECT c.claim_number, c.status, c.amount_claimed, c.incident_type FROM claims c JOIN policies p ON p.id=c.policy_id WHERE p.client_id=? ORDER BY c.id DESC", cid),
                "staff", !u.str("role").equals("client"));
    }

    /** PUT /api/clientfile : save client information (company registration, country, contact person, notes) */
    @PutMapping("/api/clientfile")
    public Object saveProfile(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row u = c.need(); Long cid = u.str("role").equals("client") ? c.ids(u)[0] : toLong(d.get("client_id"));
        if (cid == null || !c.clientOk(u, cid)) throw new ApiException(404, "Client not found");
        db.run("UPDATE clients SET reg_no=?, country=?, contact_person=?, notes=? WHERE id=?", cut(d.get("reg_no")), cut(d.get("country")), cut(d.get("contact_person")), cut(d.get("notes")), cid);
        if (u.str("role").equals("client")) db.run("UPDATE clients SET kyc_status='Pending' WHERE id=? AND kyc_status='Verified'", cid);   // changed data must be checked again
        c.audit("edit client file", String.valueOf(cid)); return m("ok", true);
    }
    private static String cut(Object o) { String t = strip(o); return t.length() > 300 ? t.substring(0, 300) : t; }

    /** POST /api/clientfile/kyc : broker / admin sets the KYC status. "Verified" needs every required document verified first. */
    @PostMapping("/api/clientfile/kyc")
    public Object kyc(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row u = c.need("broker", "admin"); Long cid = toLong(d.get("client_id"));
        if (cid == null || !c.clientOk(u, cid)) throw new ApiException(404, "Client not found");
        String status = s(d.get("status"));
        if (!List.of("Pending", "Verified", "Rejected").contains(status)) throw bad("Choose a status");
        if (status.equals("Verified")) {
            List<Row> docs = db.q("SELECT doc_type, status FROM documents WHERE client_id=?", cid);
            List<String> missing = REQUIRED_DOCS.stream().filter(t -> !best(docs, t).equals("Verified")).toList();
            if (!missing.isEmpty()) throw bad("Verify these documents first: " + String.join(", ", missing));
        }
        db.run("UPDATE clients SET kyc_status=? WHERE id=?", status, cid);
        c.push(db.one("SELECT user_id FROM clients WHERE id=?", cid).l("user_id"), "kyc", "Your client file status is now: " + status + ".");
        c.audit("kyc " + status.toLowerCase(), String.valueOf(cid)); return m("ok", true);
    }

    /** Like werkzeug's secure_filename. */
    static String secureFilename(String name) {
        name = name.replace('\\', '/'); name = name.substring(name.lastIndexOf('/') + 1);
        name = Normalizer.normalize(name, Normalizer.Form.NFKD).replaceAll("[^\\x00-\\x7F]", "");
        name = name.trim().replaceAll("\\s+", "_").replaceAll("[^A-Za-z0-9_.-]", "").replaceAll("^[._]+|[._]+$", "");
        return name;
    }

    /** POST /api/documents : upload one file (pdf, png, jpg, docx, xlsx; max 8 MB). The real file content is checked, the file gets a random name. */
    @PostMapping("/api/documents")
    public Object upload(@RequestParam(value = "file", required = false) MultipartFile f, @RequestParam Map<String, String> form) throws IOException {
        Row u = c.need(); Long cid = u.str("role").equals("client") ? c.ids(u)[0] : toLong(form.get("client_id"));
        if (cid == null || !c.clientOk(u, cid)) throw bad("Choose a client you may upload for");
        if (f == null || f.getOriginalFilename() == null || f.getOriginalFilename().isEmpty()) throw bad("Choose a file");
        String fn = f.getOriginalFilename(); String ext = fn.contains(".") ? fn.substring(fn.lastIndexOf('.') + 1).toLowerCase() : "";
        if (!ALLOWED.containsKey(ext)) throw bad("Allowed file types: " + String.join(", ", ALLOWED.keySet()));
        byte[] data = f.getBytes(), magic = ALLOWED.get(ext);
        if (data.length < magic.length || !Arrays.equals(Arrays.copyOf(data, magic.length), magic)) throw bad("The file content does not match its type");
        String docType = form.get("doc_type");
        if (!DOC_TYPES.contains(docType)) throw bad("Choose a document type");
        Long pid = toLong(form.get("policy_id")), clid = toLong(form.get("claim_id"));
        if (pid != null && pid != 0 && !db.exists("SELECT 1 FROM policies WHERE id=? AND client_id=?", pid, cid)) throw bad("Policy does not belong to this client");
        if (clid != null && clid != 0 && !db.exists("SELECT 1 FROM claims c JOIN policies p ON p.id=c.policy_id WHERE c.id=? AND p.client_id=?", clid, cid)) throw bad("Claim does not belong to this client");
        byte[] rnd = new byte[16]; new SecureRandom().nextBytes(rnd); String stored = HexFormat.of().formatHex(rnd) + "." + ext;
        Files.createDirectories(c.props.upDir); Files.write(c.props.upDir.resolve(stored), data);
        String safe = secureFilename(fn);
        long did = db.run("INSERT INTO documents(client_id,policy_id,claim_id,doc_type,filename,stored_name,status,uploaded_by,uploaded_at) VALUES(?,?,?,?,?,?,'Pending',?,?)",
                cid, pid == null || pid == 0 ? null : pid, clid == null || clid == 0 ? null : clid, docType, safe.isEmpty() ? "document." + ext : safe, stored, u.get("id"), now());
        Row cl = db.one("SELECT cl.user_id cu, b.user_id bu FROM clients cl LEFT JOIN brokers b ON b.id=cl.broker_id WHERE cl.id=?", cid);
        Set<Long> who = new LinkedHashSet<>(); if (cl.lng("cu") != null) who.add(cl.lng("cu")); if (cl.lng("bu") != null) who.add(cl.lng("bu")); who.remove(u.l("id"));
        for (Long uid : who) c.push(uid, "document", "New document uploaded: " + docType + ".");
        c.audit("upload document", String.valueOf(did)); return m("ok", true);
    }

    private Row docFor(Row u, long did) {
        Row d = db.one("SELECT * FROM documents WHERE id=?", did);
        return d != null && c.clientOk(u, d.lng("client_id")) ? d : null;
    }

    /** GET /api/documents/{did}/file : download (only if you may see this client) */
    @GetMapping("/api/documents/{did}/file")
    public ResponseEntity<byte[]> download(@PathVariable long did) throws IOException {
        Row d = docFor(c.need(), did);
        if (d == null) throw new ApiException(404, "Document not found");
        Path file = c.props.upDir.resolve(d.s("stored_name"));
        if (!Files.exists(file)) throw new ApiException(404, "Document not found");
        c.audit("download document", String.valueOf(did));
        return ResponseEntity.ok().contentType(MediaTypeFactory.getMediaType(d.s("filename")).orElse(MediaType.APPLICATION_OCTET_STREAM))
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(d.s("filename")).build().toString()).body(Files.readAllBytes(file));
    }

    /** POST /api/documents/{did}/review : broker / admin verifies or rejects a document */
    @PostMapping("/api/documents/{did}/review")
    public Object review(@PathVariable long did, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> data = body(body); Row d = docFor(c.need("broker", "admin"), did);
        if (d == null) throw new ApiException(404, "Document not found");
        String status = s(data.get("status"));
        if (!status.equals("Verified") && !status.equals("Rejected")) throw bad("Choose Verified or Rejected");
        String note = strip(data.get("note")); if (note.length() > 300) note = note.substring(0, 300);
        if (status.equals("Rejected") && note.isEmpty()) throw bad("Please say why the document is rejected");
        db.run("UPDATE documents SET status=?, note=? WHERE id=?", status, note, did);
        c.push(db.one("SELECT user_id FROM clients WHERE id=?", d.get("client_id")).l("user_id"), "document", "Your document (" + d.s("doc_type") + ") is " + status + "." + (note.isEmpty() ? "" : " " + note));
        c.audit("document " + status.toLowerCase(), String.valueOf(did)); return m("ok", true);
    }

    /** DELETE /api/documents/{did} : remove a document that is still Pending (uploader or admin) */
    @DeleteMapping("/api/documents/{did}")
    public Object delete(@PathVariable long did) {
        Row u = c.need(); Row d = docFor(u, did);
        if (d == null) throw new ApiException(404, "Document not found");
        if (!d.s("status").equals("Pending") || (!u.str("role").equals("admin") && d.l("uploaded_by") != u.l("id"))) throw bad("Only your own pending documents can be removed");
        try { Files.deleteIfExists(c.props.upDir.resolve(d.s("stored_name"))); } catch (IOException ignored) { }
        db.run("DELETE FROM documents WHERE id=?", did); c.audit("delete document", String.valueOf(did)); return m("ok", true);
    }
}
