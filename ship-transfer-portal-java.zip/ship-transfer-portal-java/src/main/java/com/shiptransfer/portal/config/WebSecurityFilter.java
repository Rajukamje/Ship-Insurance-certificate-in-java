package com.shiptransfer.portal.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** security.py - CSRF token on every change request, rate limit on login/register, security headers. */
@Component
public class WebSecurityFilter extends OncePerRequestFilter {
    private static final Map<String, Integer> LIMITED = Map.of("/api/login", 15, "/api/register", 10, "/api/forgot", 8, "/api/reset", 10);   // max POST per minute per IP
    private final Map<String, List<Long>> hits = new ConcurrentHashMap<>();
    private final AppProps props;
    public WebSecurityFilter(AppProps props) { this.props = props; }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse resp, FilterChain chain) throws ServletException, IOException {
        headers(req, resp);
        String path = req.getRequestURI(), method = req.getMethod();
        // chatbot API (/api/bot/): called by Cognigy with X-BOT-KEY + chat token, never with the login cookie
        if (path.startsWith("/api/") && !path.startsWith("/api/bot/")) {
            if (method.equals("POST") || method.equals("PUT") || method.equals("DELETE")) {          // CSRF: token given by /api/me
                HttpSession s = req.getSession(false);
                String token = s == null ? null : (String) s.getAttribute("csrf");
                String sent = Optional.ofNullable(req.getHeader("X-CSRF-Token")).orElse("");
                if (token == null || !MessageDigest.isEqual(token.getBytes(StandardCharsets.UTF_8), sent.getBytes(StandardCharsets.UTF_8))) {
                    json(resp, 403, "Security check failed. Please reload the page."); return;
                }
            }
            Integer limit = LIMITED.get(path);
            if (limit != null && method.equals("POST") && !props.rateLimitOff) {                      // brute-force protection
                String key = req.getRemoteAddr() + path; long now = System.currentTimeMillis();
                List<Long> recent = new ArrayList<>(hits.getOrDefault(key, List.of())); recent.removeIf(t -> now - t >= 60_000);
                if (recent.size() >= limit) { json(resp, 429, "Too many attempts. Please wait a minute."); return; }
                recent.add(now); hits.put(key, recent);
            }
        }
        chain.doFilter(req, resp);
    }

    private void headers(HttpServletRequest req, HttpServletResponse resp) {
        resp.setHeader("X-Content-Type-Options", "nosniff");
        resp.setHeader("X-Frame-Options", "SAMEORIGIN");
        resp.setHeader("Referrer-Policy", "same-origin");
        String bot = props.cognigyEnabled ? props.cognigyHosts() : "";
        String gh = props.cognigyEnabled ? "https://github.com https://*.githubusercontent.com" : "";
        resp.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline' " + gh + "; style-src 'self' 'unsafe-inline'; "
                + "img-src 'self' data: blob: https:; font-src 'self' data:; connect-src 'self' " + bot + "; frame-src " + (bot.isEmpty() ? "'none'" : bot) + "; "
                + "media-src 'self' blob: https:; object-src 'none'; frame-ancestors 'self'; form-action 'self'; base-uri 'self'");
        if (props.httpsOn) resp.setHeader("Strict-Transport-Security", "max-age=31536000");
        if (req.getRequestURI().startsWith("/api/")) resp.setHeader("Cache-Control", "no-store");
    }

    private static void json(HttpServletResponse resp, int code, String msg) throws IOException {
        resp.setStatus(code); resp.setContentType("application/json"); resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write("{\"error\":\"" + msg.replace("\"", "\\\"") + "\"}");
    }
}
