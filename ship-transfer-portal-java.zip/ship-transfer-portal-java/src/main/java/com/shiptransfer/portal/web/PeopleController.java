package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/people.py - Clients and brokers module. */
@RestController
public class PeopleController {
    private final Core c; private final Db db;
    public PeopleController(Core c) { this.c = c; this.db = c.db; }

    /** GET /api/clients : client table */
    @GetMapping("/api/clients")
    public Object clients() {
        Row u = c.need("broker", "admin"); boolean admin = u.str("role").equals("admin");
        return db.q("""
                SELECT cl.id, cu.name, cu.company, cu.email, cl.broker_id, cu.status, cl.kyc_status, cl.country,
                 COALESCE(NULLIF(bu.company,''),bu.name,'Unassigned') broker,
                 (SELECT COUNT(*) FROM policies p WHERE p.client_id=cl.id) policies
                 FROM clients cl JOIN users cu ON cu.id=cl.user_id LEFT JOIN brokers b ON b.id=cl.broker_id LEFT JOIN users bu ON bu.id=b.user_id """
                + (admin ? "" : "WHERE cl.broker_id=?"), admin ? new Object[0] : new Object[]{c.ids(u)[1]});
    }

    /** PUT /api/clients/{cid} : admin assigns a broker */
    @PutMapping("/api/clients/{cid}")
    public Object assignBroker(@PathVariable long cid, @RequestBody(required = false) Map<String, Object> body) {
        c.need("admin"); Long bid = toLong(body(body).get("broker_id")); if (bid != null && bid == 0) bid = null;
        db.run("UPDATE clients SET broker_id=? WHERE id=?", bid, cid); c.audit("assign broker", "client " + cid);
        return m("ok", true);
    }

    /** GET /api/brokers : broker table */
    @GetMapping("/api/brokers")
    public Object brokers() {
        c.need("admin");
        return db.q("SELECT b.id, u.name, u.email, u.company, b.category, b.status FROM brokers b JOIN users u ON u.id=b.user_id WHERE b.deleted_at IS NULL");
    }

    /** POST /api/brokers : admin adds a broker */
    @PostMapping("/api/brokers")
    public Object addBroker(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); c.need("admin"); String email = s(d.get("email"));
        if (!EMAIL.matcher(email).matches() || db.exists("SELECT 1 FROM users WHERE email=?", email.toLowerCase())) throw bad("Valid, unique email required");
        if (!truthy(d.get("name")) || !strong(s(d.get("password")))) throw bad("Name required. " + PW_MSG);
        long uid = db.run("INSERT INTO users(name,email,phone,password,role,company) VALUES(?,?,?,?, 'broker', ?)", s(d.get("name")), email.toLowerCase(), s(d.get("phone")), DbInit.PW.encode(s(d.get("password"))), s(d.get("company")));
        db.run("INSERT INTO brokers(user_id,category) VALUES(?,?)", uid, d.get("category") == null ? "Marine" : s(d.get("category"))); c.audit("add broker", email);
        return m("ok", true);
    }

    /** PUT /api/brokers/{bid} : admin edits a broker */
    @PutMapping("/api/brokers/{bid}")
    public Object editBroker(@PathVariable long bid, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); c.need("admin");
        db.run("UPDATE brokers SET category=COALESCE(?,category), status=COALESCE(?,status) WHERE id=?", d.get("category"), d.get("status"), bid);
        c.audit("edit broker", String.valueOf(bid)); return m("ok", true);
    }

    /** DELETE /api/brokers/{bid} : soft delete (hidden, not erased, so old records stay correct) */
    @DeleteMapping("/api/brokers/{bid}")
    public Object delBroker(@PathVariable long bid) {
        c.need("admin");
        db.run("UPDATE brokers SET deleted_at=?, status='Inactive' WHERE id=?", now(), bid);
        db.run("UPDATE users SET status='Inactive' WHERE id=(SELECT user_id FROM brokers WHERE id=?)", bid);
        c.audit("delete broker", String.valueOf(bid)); return m("ok", true);
    }
}
