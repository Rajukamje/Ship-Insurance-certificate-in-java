package com.shiptransfer.portal.core;

import com.shiptransfer.portal.config.AppProps;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

import static com.shiptransfer.portal.core.U.*;

/** core.py - shared helpers: who is logged in, role checks (enforced on the server), data scope, audit log, validation, statuses, quotes, invoices, reminders. */
@Component
public class Core {
    public final Db db;
    public final AppProps props;
    @Autowired private HttpServletRequest request;           // proxy of the current request

    public Core(Db db, AppProps props) { this.db = db; this.props = props; }

    // ---------------------------------------------------------------- constants
    public static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
    public static final List<String> CLAIM_TYPES = List.of("Collision", "Grounding", "Fire / Explosion", "Heavy weather damage", "Machinery breakdown", "Cargo damage", "Cargo theft", "Total loss", "Liability / third party", "Other");
    public static final List<String> DOC_TYPES = List.of("ID / Company registration", "Ship registry certificate", "Class certificate", "Survey report",
            "Cargo manifest / Bill of lading", "Commercial invoice", "Claim evidence (photos / report)", "Other");
    public static final List<String> REQUIRED_DOCS = DOC_TYPES.subList(0, 4);        // documents a broker must collect before the client is "KYC Verified"

    public static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    public static final Pattern PHONE = Pattern.compile("^\\+?[0-9 \\-]{7,15}$");
    public static final String PW_MSG = "Password needs 8+ characters with upper case, lower case, number and symbol";

    public static final String POL_SQL = """
            SELECT p.*, s.name ship_name, s.imo, COALESCE(NULLIF(cu.company,''),cu.name) client,
             COALESCE(NULLIF(bu.company,''),bu.name,'Unassigned') broker
             FROM policies p JOIN ships s ON s.id=p.ship_id JOIN clients cl ON cl.id=p.client_id JOIN users cu ON cu.id=cl.user_id
             LEFT JOIN brokers b ON b.id=p.broker_id LEFT JOIN users bu ON bu.id=b.user_id """;
    public static final String CERT_SQL = """
            SELECT c.*, p.policy_number, p.type cover, p.premium, p.status pstat, p.end_date, s.name ship_name, s.imo, s.flag,
             s.type ship_type, s.tonnage, COALESCE(NULLIF(cu.company,''),cu.name) insured, cu.address,
             COALESCE(NULLIF(bu.company,''),bu.name,'Direct') broker
             FROM certificates c JOIN policies p ON p.id=c.policy_id JOIN ships s ON s.id=p.ship_id JOIN clients cl ON cl.id=p.client_id
             JOIN users cu ON cu.id=cl.user_id LEFT JOIN brokers b ON b.id=p.broker_id LEFT JOIN users bu ON bu.id=b.user_id """;

    // ---------------------------------------------------------------- time
    public static String now() { return LocalDateTime.now().format(TS); }
    public static LocalDate today() { return LocalDate.now(); }
    public static LocalDate pdate(String s) { try { return LocalDate.parse(s); } catch (Exception e) { return null; } }

    // ---------------------------------------------------------------- validation
    public static boolean strong(String p) {
        return p != null && p.length() >= 8 && Pattern.compile("[a-z]").matcher(p).find() && Pattern.compile("[A-Z]").matcher(p).find()
                && Pattern.compile("\\d", Pattern.UNICODE_CHARACTER_CLASS).matcher(p).find()
                && Pattern.compile("[^\\w\\s]", Pattern.UNICODE_CHARACTER_CLASS).matcher(p).find();
    }

    // ---------------------------------------------------------------- statuses
    public static String pstatus(String status, String endDate) {
        if ("Cancelled".equals(status)) return "Cancelled";
        if (endDate.compareTo(today().toString()) < 0) return "Expired";
        if (endDate.compareTo(today().plusDays(30).toString()) <= 0) return "Expiring Soon";
        return "Active";
    }
    public static String pstatus(Row p) { return pstatus(p.str("status"), p.str("end_date")); }
    public static String cstatus(Row c) {
        if ("Issued".equals(c.str("status")) && c.str("valid_to").compareTo(today().toString()) < 0) return "Expired";
        return c.str("status");
    }
    public static String istatus(Row i) {
        if ("Paid".equals(i.str("status"))) return "Paid";
        return i.str("due_date").compareTo(today().toString()) < 0 ? "Overdue" : "Unpaid";
    }
    public static long daysLeft(String end) { return java.time.temporal.ChronoUnit.DAYS.between(today(), LocalDate.parse(end)); }

    // ---------------------------------------------------------------- audit / notifications
    /** Write the audit log. uid is given by the chatbot API (no login cookie there); websites use the logged-in user. */
    public void audit(String action, String target, Long uid) {
        if (uid == null) { Row u = current(); uid = u == null ? null : u.l("id"); }
        db.run("INSERT INTO audit(user_id,action,target,time) VALUES(?,?,?,?)", uid, action, target, now());
    }
    public void audit(String action, String target) { audit(action, target, null); }
    public void audit(String action) { audit(action, "", null); }

    public void notify(long userId, String kind, String detail) {
        db.run("INSERT INTO notifications(user_id,type,detail,sent_at) VALUES(?,?,?,?)", userId, kind, detail, now());
    }

    /** Save a notification (= email log). 'ref' makes it unique, so the same reminder is never sent twice. */
    public void push(Long userId, String kind, String detail, String ref) {
        if (userId == null) return;
        if (ref != null && db.exists("SELECT 1 FROM notifications WHERE user_id=? AND ref=?", userId, ref)) return;
        db.run("INSERT INTO notifications(user_id,type,detail,sent_at,ref) VALUES(?,?,?,?,?)", userId, kind, detail, now(), ref);
    }
    public void push(Long userId, String kind, String detail) { push(userId, kind, detail, null); }

    // ---------------------------------------------------------------- who is logged in
    public Row current() {
        HttpSession s = request.getSession(false);
        Object uid = s == null ? null : s.getAttribute("uid");
        return uid == null ? null : db.one("SELECT * FROM users WHERE id=?", uid);
    }

    /** Role check, enforced on the server for every request. */
    public Row need(String... roles) {
        Row u = current();
        if (u == null) throw new ApiException(401, "Please log in");
        if (roles.length > 0 && !Arrays.asList(roles).contains(u.str("role"))) throw new ApiException(403, "Access denied for your role");
        return u;
    }

    /** {clientId, brokerId} of a user (null where the user has none). */
    public Long[] ids(Row u) {
        Row c = db.one("SELECT id FROM clients WHERE user_id=?", u.get("id"));
        Row b = db.one("SELECT id FROM brokers WHERE user_id=?", u.get("id"));
        return new Long[]{c == null ? null : c.l("id"), b == null ? null : b.l("id")};
    }

    public record Scope(String sql, Object[] args) { }

    /** SQL fragment limiting policies to what this role may see. */
    public Scope scope(Row u, String a) {
        Long[] id = ids(u);
        return switch (u.s("role")) {
            case "admin" -> new Scope("1=1", new Object[0]);
            case "broker" -> new Scope(a + ".broker_id=?", new Object[]{id[1]});
            default -> new Scope(a + ".client_id=?", new Object[]{id[0]});
        };
    }
    public Scope scope(Row u) { return scope(u, "p"); }

    /** May this user work with this client? Admin: any. Broker: assigned clients. Client: only himself. */
    public boolean clientOk(Row u, Long cid) {
        if ("admin".equals(u.str("role"))) return true;
        if (cid == null) return false;
        Row cl = db.one("SELECT * FROM clients WHERE id=?", cid);
        if (cl == null) return false;
        Long[] id = ids(u);
        return ("client".equals(u.str("role")) && Objects.equals(cl.lng("id"), id[0]))
                || ("broker".equals(u.str("role")) && id[1] != null && Objects.equals(cl.lng("broker_id"), id[1]));
    }

    public List<Row> certList(Row u) { return certList(u, ""); }

    public List<Row> certList(Row u, String where, Object... args) {
        Scope sc = scope(u);
        List<Row> rows = db.q(CERT_SQL + " WHERE " + sc.sql() + " " + where + " ORDER BY c.id DESC", cat(sc.args(), args));
        for (Row c : rows) c.put("status", cstatus(c));
        return rows;
    }

    /** User ids of the client and the broker of a policy. */
    public List<Long> parties(long policyId) {
        Row r = db.one("SELECT cl.user_id cu, b.user_id bu FROM policies p JOIN clients cl ON cl.id=p.client_id LEFT JOIN brokers b ON b.id=p.broker_id WHERE p.id=?", policyId);
        List<Long> out = new ArrayList<>();
        if (r != null) { if (r.lng("cu") != null) out.add(r.lng("cu")); if (r.lng("bu") != null) out.add(r.lng("bu")); }
        return out;
    }

    public List<Long> adminIds() { return db.q("SELECT id FROM users WHERE role='admin'").stream().map(r -> r.l("id")).toList(); }

    // ---------------------------------------------------------------- premium
    /** rate % of the sum insured + add-ons (war & strikes, Build Back Better) + loading for old vessels + loading for earlier claims. */
    public Map<String, Object> quote(Row plan, double sumInsured, int yearBuilt, boolean war, boolean bbb, Long clientId) {
        double rate = plan.dbl("rate") + (war ? 0.05 : 0) + (bbb ? 0.04 : 0);
        double base = sumInsured * rate / 100;
        int age = yearBuilt > 0 ? today().getYear() - yearBuilt : 0;
        double ageLoad = age >= 20 ? 0.15 : age >= 10 ? 0.07 : 0.0;
        long n = clientId == null ? 0 : db.count("SELECT COUNT(*) n FROM claims c JOIN policies p ON p.id=c.policy_id WHERE p.client_id=? AND c.status!='Rejected'", clientId);
        double claimsLoad = Math.min(0.05 * n, 0.20);
        return m("rate", round(rate, 3), "base", round(base, 2), "age", age, "age_load", ageLoad, "claims_count", n, "claims_load", claimsLoad,
                "premium", round(base * (1 + ageLoad + claimsLoad), 2), "deductible", plan.get("deductible"));
    }

    /** New unpaid invoice, due in 14 days. */
    public long createInvoice(long policyId, long clientId, double amount, String description) {
        long iid = db.run("INSERT INTO invoices(policy_id,client_id,description,amount,issue_date,due_date,status) VALUES(?,?,?,?,?,?,'Unpaid')",
                policyId, clientId, description, amount, today().toString(), today().plusDays(14).toString());
        db.run("UPDATE invoices SET invoice_number=? WHERE id=?", "INV-" + today().getYear() + "-" + pad6(iid), iid);
        return iid;
    }

    // ---------------------------------------------------------------- reminders
    private record Level(String lvl, long left) { }
    private static Level level(String end) {
        long left = daysLeft(end);
        if (left >= -30 && left < 0) return new Level("expired", left);
        if (left >= 0 && left <= 30) return new Level(left <= 7 ? "7" : left <= 15 ? "15" : "30", left);
        return new Level(null, left);
    }

    /** Notifications: policy / certificate expiring in 30, 15, 7 days, expired, and overdue invoices. Safe to run often (no duplicates). */
    public synchronized void runReminders() {
        for (Row p : db.q("SELECT * FROM policies WHERE status!='Cancelled'")) {
            Level l = level(p.str("end_date")); if (l.lvl() == null) continue;
            String msg = l.lvl().equals("expired") ? "Policy " + p.str("policy_number") + " has expired. Renew it to stay covered."
                    : "Policy " + p.str("policy_number") + " expires in " + l.left() + " day(s). Renew it now.";
            for (Long uid : parties(p.l("id"))) push(uid, "reminder", msg, "pol:" + p.l("id") + ":" + l.lvl());
        }
        for (Row c : db.q("SELECT * FROM certificates WHERE status='Issued'")) {
            Level l = level(c.str("valid_to")); if (l.lvl() == null) continue;
            String msg = l.lvl().equals("expired") ? "Certificate " + c.str("certificate_number") + " has expired. Request a renewal."
                    : "Certificate " + c.str("certificate_number") + " expires in " + l.left() + " day(s). Renew it now.";
            for (Long uid : parties(c.l("policy_id"))) push(uid, "reminder", msg, "cert:" + c.l("id") + ":" + l.lvl());
        }
        for (Row i : db.q("SELECT * FROM invoices WHERE status!='Paid' AND due_date < ?", today().toString()))
            for (Long uid : parties(i.l("policy_id")))
                push(uid, "invoice", "Invoice " + i.str("invoice_number") + " is overdue (USD " + usd0(i.dbl("amount")) + ").", "inv:" + i.l("id") + ":overdue");
    }
}
