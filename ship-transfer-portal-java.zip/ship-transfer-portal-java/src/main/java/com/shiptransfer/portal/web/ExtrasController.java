package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Map;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/extras.py - forgot / reset password, notifications, public statistics, newsletter and contact form. */
@RestController
public class ExtrasController {
    private final Core c; private final Db db;
    public ExtrasController(Core c) { this.c = c; this.db = c.db; }

    /** POST /api/forgot : create a reset link that is valid 30 minutes */
    @PostMapping("/api/forgot")
    public Object forgot(@RequestBody(required = false) Map<String, Object> body) {
        String email = strip(body(body).get("email")).toLowerCase(); Row u = db.one("SELECT * FROM users WHERE email=?", email); String link = null;
        if (u != null) {                                                  // same answer whether the email exists or not (does not reveal accounts)
            byte[] b = new byte[24]; new SecureRandom().nextBytes(b); String token = Base64.getUrlEncoder().withoutPadding().encodeToString(b);
            db.run("INSERT INTO password_resets(token,user_id,expires) VALUES(?,?,?)", token, u.get("id"), LocalDateTime.now().plusMinutes(30).format(TS));
            link = "/reset.html?token=" + token; c.notify(u.l("id"), "password reset", "Reset link (valid 30 minutes): " + link);
        }
        return m("ok", true, "message", "If this email exists, a reset link was sent. It expires in 30 minutes.", "demo_link", c.props.demoMode ? link : null);
    }

    /** POST /api/reset : set a new password with the token */
    @PostMapping("/api/reset")
    public Object reset(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row r = db.one("SELECT * FROM password_resets WHERE token=?", s(d.get("token")));
        if (r == null || r.s("expires").compareTo(now()) < 0) throw bad("Reset link is invalid or expired");
        if (!strong(s(d.get("password")))) throw bad(PW_MSG);
        if (!s(d.get("password")).equals(s(d.get("confirm")))) throw bad("Passwords do not match");
        db.run("UPDATE users SET password=?, failed=0, locked_until=NULL WHERE id=?", DbInit.PW.encode(s(d.get("password"))), r.get("user_id"));
        db.run("DELETE FROM password_resets WHERE user_id=?", r.get("user_id")); return m("ok", true);
    }

    /** GET /api/notifications : my notifications. ?count=1 gives only the number of the last 7 days. */
    @GetMapping("/api/notifications")
    public Object notifications(HttpServletRequest req) {
        Row u = c.need(); c.runReminders();
        if (!s(req.getParameter("count")).isEmpty())
            return m("count", db.count("SELECT COUNT(*) n FROM notifications WHERE user_id=? AND sent_at >= ?", u.get("id"), LocalDateTime.now().minusDays(7).format(TS)));
        return db.q("SELECT type, detail, sent_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 60", u.get("id"));
    }

    /** GET /api/stats : PUBLIC numbers for the landing page */
    @GetMapping("/api/stats")
    public Object stats() {
        return m("certificates", db.count("SELECT COUNT(*) n FROM certificates WHERE status='Issued'"), "policies", db.count("SELECT COUNT(*) n FROM policies"),
                "ships", db.count("SELECT COUNT(*) n FROM ships"), "brokers", db.count("SELECT COUNT(*) n FROM brokers WHERE deleted_at IS NULL"));
    }

    /** POST /api/newsletter : footer sign-up */
    @PostMapping("/api/newsletter")
    public Object newsletter(@RequestBody(required = false) Map<String, Object> body) {
        String email = strip(body(body).get("email")).toLowerCase();
        if (!EMAIL.matcher(email).matches()) throw bad("Enter a valid email");
        db.run("INSERT OR IGNORE INTO subscribers(email,created_at) VALUES(?,?)", email, now()); return m("ok", true);
    }

    private static String cut(Object o, int n) { String t = s(o); return t.length() > n ? t.substring(0, n) : t; }

    /** POST /api/contact : contact form */
    @PostMapping("/api/contact")
    public Object contact(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body);
        if (!truthy(d.get("name")) || !EMAIL.matcher(s(d.get("email"))).matches() || strip(d.get("message")).length() < 10) throw bad("Name, a valid email and a message (10+ characters) are required");
        db.run("INSERT INTO messages(name,email,topic,message,created_at) VALUES(?,?,?,?,?)", cut(d.get("name"), 100), s(d.get("email")), d.get("topic") == null ? "General" : cut(d.get("topic"), 60), cut(d.get("message"), 2000), now());
        return m("ok", true);
    }

    /** GET /api/messages : admin inbox (contact messages + newsletter count) */
    @GetMapping("/api/messages")
    public Object messages() {
        c.need("admin");
        return m("messages", db.q("SELECT * FROM messages ORDER BY id DESC LIMIT 100"), "subscribers", db.count("SELECT COUNT(*) n FROM subscribers"));
    }
}
