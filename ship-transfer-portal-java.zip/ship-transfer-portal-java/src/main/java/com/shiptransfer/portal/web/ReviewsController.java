package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/reviews.py - Broker directory with ratings and reviews. Clients can choose a broker and review the broker they worked with. */
@RestController
public class ReviewsController {
    private final Core c; private final Db db;
    public ReviewsController(Core c) { this.c = c; this.db = c.db; }

    /** GET /api/directory : active brokers with average rating, review count and the latest reviews */
    @GetMapping("/api/directory")
    public Object directory() {
        Row u = c.need(); Long cid = u.str("role").equals("client") ? c.ids(u)[0] : null;
        Long mine = cid == null ? null : db.one("SELECT broker_id FROM clients WHERE id=?", cid).lng("broker_id");
        List<Row> out = new ArrayList<>();
        for (Row b : db.q("SELECT b.id, u.name, u.company, b.category FROM brokers b JOIN users u ON u.id=b.user_id WHERE b.deleted_at IS NULL AND b.status='Active' ORDER BY b.id")) {
            Row r = db.one("SELECT ROUND(AVG(rating),1) avg, COUNT(*) n FROM reviews WHERE broker_id=?", b.get("id"));
            b.put("avg", r.dblOrNull("avg") == null ? (Object) 0 : r.get("avg")); b.put("count", r.get("n"));
            b.put("clients", db.count("SELECT COUNT(*) n FROM clients WHERE broker_id=?", b.get("id")));
            b.put("reviews", db.q("""
                    SELECT r.rating, r.comment, r.created_at, COALESCE(NULLIF(u.company,''),u.name) client FROM reviews r JOIN clients c ON c.id=r.client_id
                     JOIN users u ON u.id=c.user_id WHERE r.broker_id=? ORDER BY r.id DESC LIMIT 5""", b.get("id")));
            boolean isMine = Objects.equals(mine, b.lng("id"));
            b.put("mine", isMine);
            b.put("can_review", cid != null && (isMine || db.exists("SELECT 1 FROM policies WHERE client_id=? AND broker_id=?", cid, b.get("id"))));
            out.add(b);
        }
        return out;
    }

    /** POST /api/brokers/{bid}/reviews : a client rates (1-5) and comments on a broker he worked with (one review per client, can be changed) */
    @PostMapping("/api/brokers/{bid}/reviews")
    public Object write(@PathVariable long bid, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row u = c.need("client"); long cid = c.ids(u)[0];
        Row cl = db.one("SELECT * FROM clients WHERE id=?", cid);
        if (!(Objects.equals(cl.lng("broker_id"), bid) || db.exists("SELECT 1 FROM policies WHERE client_id=? AND broker_id=?", cid, bid)))
            throw bad("You can review a broker only after choosing him or having a policy with him");
        Integer rating = toInt(d.get("rating"));
        if (rating == null) throw bad("Choose a rating from 1 to 5");
        String comment = strip(d.get("comment")); if (comment.length() > 500) comment = comment.substring(0, 500);
        if (rating < 1 || rating > 5) throw bad("Choose a rating from 1 to 5");
        db.run("""
                INSERT INTO reviews(broker_id,client_id,rating,comment,created_at) VALUES(?,?,?,?,?)
                ON CONFLICT(broker_id,client_id) DO UPDATE SET rating=excluded.rating, comment=excluded.comment, created_at=excluded.created_at""", bid, cid, rating, comment, now());
        c.audit("review broker", String.valueOf(bid)); return m("ok", true);
    }

    /** POST /api/me/broker : a client chooses his broker */
    @PostMapping("/api/me/broker")
    public Object choose(@RequestBody(required = false) Map<String, Object> body) {
        Row u = c.need("client");
        Row b = db.one("SELECT b.*, u.name FROM brokers b JOIN users u ON u.id=b.user_id WHERE b.id=? AND b.deleted_at IS NULL AND b.status='Active'", toInt(body(body).get("broker_id")));
        if (b == null) throw bad("Broker not found");
        long cid = c.ids(u)[0];
        db.run("UPDATE clients SET broker_id=? WHERE id=?", b.get("id"), cid);
        db.run("UPDATE policies SET broker_id=? WHERE client_id=?", b.get("id"), cid);          // the new broker also handles the existing policies
        c.push(b.l("user_id"), "client", u.s("name") + " chose you as broker. Please collect the client's information and documents.");
        c.audit("choose broker", b.s("id")); return m("ok", true);
    }
}
