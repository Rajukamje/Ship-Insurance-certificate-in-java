package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/policies.py - Policies: list, create (plan + automatic premium + invoice), cancel, renew. */
@RestController
public class PoliciesController {
    private final Core c; private final Db db;
    public PoliciesController(Core c) { this.c = c; this.db = c.db; }

    private List<Row> policyRows(Row u) {
        Core.Scope sc = c.scope(u);
        List<Row> rows = db.q(POL_SQL + " WHERE " + sc.sql() + " ORDER BY p.id DESC", sc.args());
        for (Row p : rows) {
            p.put("status", pstatus(p));                                               // Active / Expiring Soon / Expired / Cancelled
            p.put("days_left", daysLeft(p.s("end_date")));
            p.put("renewed", db.exists("SELECT 1 FROM policies WHERE renewed_from=?", p.get("id")));
        }
        return rows;
    }

    /** GET /api/policies : policies this role may see */
    @GetMapping("/api/policies")
    public Object policies() { return policyRows(c.need()); }

    /** POST /api/policies : create a policy with its ship. The premium is calculated by the server from the plan (cannot be typed in). */
    @PostMapping("/api/policies")
    public Object add(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row u = c.need();
        Long cid = u.str("role").equals("client") ? c.ids(u)[0] : null;
        if (!u.str("role").equals("client")) { cid = toLong(d.get("client_id")); if (cid == null) throw bad("Choose a client"); }
        if (cid == null || cid == 0 || !c.clientOk(u, cid)) throw bad("Choose one of your clients");
        Row cl = db.one("SELECT * FROM clients WHERE id=?", cid);
        Row plan = db.one("SELECT * FROM plans WHERE id=? AND active=1", toInt(d.get("plan_id")));
        if (plan == null) throw bad("Choose an insurance plan");
        if (!s(d.get("imo")).matches("\\d{7}")) throw bad("IMO number must be 7 digits");
        LocalDate st = pdate(s(d.get("start_date"))), en = pdate(s(d.get("end_date")));
        if (st == null || en == null || !en.isAfter(st)) throw bad("End date must be after start date");
        Double si = toDouble(d.get("sum_insured")); Integer ton = blank(d.get("tonnage")) ? Integer.valueOf(0) : toInt(d.get("tonnage")); Integer yb = blank(d.get("year_built")) ? Integer.valueOf(0) : toInt(d.get("year_built"));
        if (si == null || ton == null || yb == null) throw bad("Sum insured, tonnage and year built must be numbers");
        if (si <= 0 || !truthy(d.get("ship_name"))) throw bad("Ship name and sum insured are required");
        if (yb != 0 && !(yb >= 1900 && yb <= today().getYear())) throw bad("Enter a real year built");
        int war = truthy(d.get("war_strikes")) ? 1 : 0, bbb = truthy(d.get("bbb")) ? 1 : 0;
        Map<String, Object> qt = c.quote(plan, si, yb, war == 1, bbb == 1, cid); double premium = (Double) qt.get("premium");
        long sid = db.run("INSERT INTO ships(name,imo,flag,type,tonnage,year_built,owner_client_id) VALUES(?,?,?,?,?,?,?)", s(d.get("ship_name")), s(d.get("imo")), s(d.get("flag")), s(d.get("ship_type")), ton, yb, cid);
        long pid = db.run("INSERT INTO policies(client_id,broker_id,ship_id,type,premium,start_date,end_date,plan_id,sum_insured,war_strikes,bbb) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                cid, cl.get("broker_id"), sid, plan.get("name"), premium, st.toString(), en.toString(), plan.get("id"), si, war, bbb);
        String num = "MTP-" + today().getYear() + "-" + pad6(pid); db.run("UPDATE policies SET policy_number=? WHERE id=?", num, pid);
        c.createInvoice(pid, cid, premium, "Premium for policy " + num);
        for (Long uid : c.parties(pid)) c.push(uid, "policy", "Policy " + num + " created. Premium USD " + usd0(premium) + ". An invoice was issued.");
        c.audit("create policy", num); return m("ok", true, "policy_number", num, "premium", premium);
    }

    private static boolean blank(Object o) { return o == null || o.toString().isEmpty(); }

    /** POST /api/policies/{pid}/cancel : admin cancels a policy */
    @PostMapping("/api/policies/{pid}/cancel")
    public Object cancel(@PathVariable long pid) {
        c.need("admin"); db.run("UPDATE policies SET status='Cancelled' WHERE id=?", pid); c.audit("cancel policy", String.valueOf(pid)); return m("ok", true);
    }

    /** POST /api/policies/{pid}/renew : new one-year policy after the old one (opens 60 days before the end), with a new invoice */
    @PostMapping("/api/policies/{pid}/renew")
    public Object renew(@PathVariable long pid) {
        Row u = c.need(); Core.Scope sc = c.scope(u);
        Row p = db.one("SELECT p.* FROM policies p WHERE p.id=? AND " + sc.sql(), cat(new Object[]{pid}, sc.args()));
        if (p == null) throw new ApiException(404, "Policy not found");
        String st = pstatus(p); long left = daysLeft(p.s("end_date"));
        if (st.equals("Cancelled")) throw bad("Cancelled policies cannot be renewed");
        if (left > 60) throw bad("Renewal opens 60 days before the policy ends");
        if (db.exists("SELECT 1 FROM policies WHERE renewed_from=?", pid)) throw bad("This policy was already renewed");
        Row plan = db.one("SELECT * FROM plans WHERE id=?", p.get("plan_id")), ship = db.one("SELECT * FROM ships WHERE id=?", p.get("ship_id"));
        double si = p.dbl("sum_insured");
        double premium = plan != null && si != 0 ? (Double) c.quote(plan, si, ship.i("year_built"), p.i("war_strikes") != 0, p.i("bbb") != 0, p.l("client_id")).get("premium") : p.dbl("premium");
        LocalDate start = left >= 0 ? LocalDate.parse(p.s("end_date")).plusDays(1) : today(), end = start.plusDays(364);
        long nid = db.run("INSERT INTO policies(client_id,broker_id,ship_id,type,premium,start_date,end_date,plan_id,sum_insured,war_strikes,bbb,renewed_from) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                p.get("client_id"), p.get("broker_id"), p.get("ship_id"), p.get("type"), premium, start.toString(), end.toString(), p.get("plan_id"), p.get("sum_insured"), p.get("war_strikes"), p.get("bbb"), pid);
        String num = "MTP-" + today().getYear() + "-" + pad6(nid); db.run("UPDATE policies SET policy_number=? WHERE id=?", num, nid);
        c.createInvoice(nid, p.l("client_id"), premium, "Renewal premium for policy " + num);
        for (Long uid : c.parties(nid)) c.push(uid, "policy", "Policy " + p.s("policy_number") + " was renewed as " + num + ". Premium USD " + usd0(premium) + ".");
        c.audit("renew policy", p.s("policy_number") + " -> " + num); return m("ok", true, "policy_number", num, "premium", premium);
    }
}
