package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/claims.py - submit, list, admin review (Submitted -> Under Review -> Approved -> Paid, or Rejected). */
@RestController
public class ClaimsController {
    public static final String CLAIM_SQL = """
            SELECT c.*, p.client_id, p.policy_number, p.sum_insured, s.name ship_name, COALESCE(NULLIF(cu.company,''),cu.name) client
             FROM claims c JOIN policies p ON p.id=c.policy_id JOIN ships s ON s.id=p.ship_id JOIN clients cl ON cl.id=p.client_id JOIN users cu ON cu.id=cl.user_id """;
    static final Map<String, List<String>> NEXT = Map.of("Submitted", List.of("Under Review", "Rejected"), "Under Review", List.of("Approved", "Rejected"),
            "Approved", List.of("Paid"), "Rejected", List.of(), "Paid", List.of());                // allowed status changes

    private final Core c; private final Db db;
    public ClaimsController(Core c) { this.c = c; this.db = c.db; }

    /** GET /api/claims : claims this role may see */
    @GetMapping("/api/claims")
    public Object claims() {
        Row u = c.need(); Core.Scope sc = c.scope(u);
        List<Row> rows = db.q(CLAIM_SQL + "WHERE " + sc.sql() + " ORDER BY c.id DESC", sc.args());
        for (Row r : rows) r.put("next", NEXT.get(r.s("status")));
        return m("rows", rows, "types", CLAIM_TYPES);
    }

    public record SubmitResult(boolean ok, String error, String claimNumber) { }

    /** Check and save a claim for user u. Used by the website AND by the chatbot API, so both follow exactly the same rules. */
    public SubmitResult submit(Row u, Map<String, Object> d) {
        Core.Scope sc = c.scope(u);
        Row p = db.one("SELECT p.* FROM policies p WHERE p.id=? AND " + sc.sql(), cat(new Object[]{toInt(d.get("policy_id"))}, sc.args()));
        if (p == null) return err("Choose one of your policies");
        if ("Cancelled".equals(p.str("status"))) return err("This policy is cancelled");
        LocalDate inc = pdate(s(d.get("incident_date")));
        if (inc == null || inc.isAfter(today())) return err("Incident date must be today or earlier");
        if (!(p.s("start_date").compareTo(inc.toString()) <= 0 && inc.toString().compareTo(p.s("end_date")) <= 0)) return err("The incident is outside the policy period");
        if (!CLAIM_TYPES.contains(s(d.get("incident_type")))) return err("Choose an incident type");
        if (strip(d.get("description")).length() < 10) return err("Describe what happened (at least 10 characters)");
        Double amount = toDouble(d.get("amount_claimed"));
        if (amount == null) return err("Amount claimed must be a number");
        if (amount <= 0 || (p.truthy("sum_insured") && amount > p.dbl("sum_insured"))) return err("Amount must be above zero and not more than the sum insured");
        String desc = strip(d.get("description")); if (desc.length() > 2000) desc = desc.substring(0, 2000);
        long cid = db.run("INSERT INTO claims(policy_id,incident_date,incident_type,description,amount_claimed,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,'Submitted',?,?,?)",
                p.get("id"), inc.toString(), s(d.get("incident_type")), desc, amount, u.get("id"), now(), now());
        String num = "CLM-" + today().getYear() + "-" + pad6(cid); db.run("UPDATE claims SET claim_number=? WHERE id=?", num, cid);
        List<Long> who = new ArrayList<>(c.parties(p.l("id"))); who.addAll(c.adminIds());
        for (Long uid : who) c.push(uid, "claim", "Claim " + num + " submitted for policy " + p.s("policy_number") + " (USD " + usd0(amount) + ").");
        c.audit("submit claim", num, u.l("id")); return new SubmitResult(true, null, num);
    }
    private static SubmitResult err(String m) { return new SubmitResult(false, m, null); }

    /** POST /api/claims : report a loss on one of my policies */
    @PostMapping("/api/claims")
    public Object add(@RequestBody(required = false) Map<String, Object> body) {
        SubmitResult r = submit(c.need(), body(body));
        if (!r.ok()) throw bad(r.error());
        return m("ok", true, "claim_number", r.claimNumber());
    }

    /** PUT /api/claims/{cid} : admin moves the claim forward, sets the approved amount and a decision note */
    @PutMapping("/api/claims/{cid}")
    public Object review(@PathVariable long cid, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); c.need("admin");
        Row cl = db.one("SELECT c.*, p.policy_number FROM claims c JOIN policies p ON p.id=c.policy_id WHERE c.id=?", cid);
        if (cl == null) throw new ApiException(404, "Claim not found");
        String status = d.get("status") == null ? null : s(d.get("status"));
        if (status == null || !NEXT.get(cl.s("status")).contains(status)) throw bad("A " + cl.s("status") + " claim cannot change to " + status);
        Double approved = cl.dblOrNull("amount_approved");
        if (status.equals("Approved")) {
            approved = toDouble(d.get("amount_approved"));
            if (approved == null) throw bad("Enter the approved amount");
            if (!(approved > 0 && approved <= cl.dbl("amount_claimed"))) throw bad("Approved amount must be above zero and not more than the amount claimed");
        }
        String note = strip(d.get("decision_note")); if (note.length() > 1000) note = note.substring(0, 1000);
        if (status.equals("Rejected") && note.isEmpty()) throw bad("Please give a reason for the rejection");
        db.run("UPDATE claims SET status=?, amount_approved=?, decision_note=?, updated_at=? WHERE id=?", status, approved, note.isEmpty() ? cl.get("decision_note") : note, now(), cid);
        for (Long uid : c.parties(cl.l("policy_id")))
            c.push(uid, "claim", "Claim " + cl.s("claim_number") + " is now: " + status + "." + (status.equals("Approved") || status.equals("Paid") ? " Approved USD " + usd0(approved) + "." : ""));
        c.audit("claim " + status.toLowerCase(), cl.s("claim_number")); return m("ok", true);
    }
}
