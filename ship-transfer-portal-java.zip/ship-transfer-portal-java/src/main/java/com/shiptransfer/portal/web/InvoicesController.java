package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import com.shiptransfer.portal.service.PdfService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/invoices.py - list, pay (demo, no card data is collected), PDF. */
@RestController
public class InvoicesController {
    public static final String INV_SQL = """
            SELECT i.*, p.policy_number, p.type plan, COALESCE(NULLIF(cu.company,''),cu.name) client, cu.address
             FROM invoices i JOIN policies p ON p.id=i.policy_id JOIN clients cl ON cl.id=i.client_id JOIN users cu ON cu.id=cl.user_id """;
    private final Core c; private final Db db; private final PdfService pdf;
    public InvoicesController(Core c, PdfService pdf) { this.c = c; this.db = c.db; this.pdf = pdf; }

    public List<Row> rowsFor(Row u, String where, Object... args) {
        Core.Scope sc = c.scope(u);
        List<Row> rows = db.q(INV_SQL + "WHERE " + sc.sql() + " " + where + " ORDER BY i.id DESC", cat(sc.args(), args));
        for (Row r : rows) r.put("status", istatus(r));
        return rows;
    }

    /** GET /api/invoices : invoices this role may see (status Paid / Unpaid / Overdue) */
    @GetMapping("/api/invoices")
    public Object invoices() { return rowsFor(c.need(), ""); }

    /** POST /api/invoices/{iid}/pay : mark as paid. Demo only: the method is just a label, no card or bank data is stored. */
    @PostMapping("/api/invoices/{iid}/pay")
    public Object pay(@PathVariable long iid, @RequestBody(required = false) Map<String, Object> body) {
        List<Row> rows = rowsFor(c.need(), "AND i.id=?", iid); String method = s(body(body).get("method"));
        if (rows.isEmpty()) throw new ApiException(404, "Invoice not found");
        Row inv = rows.get(0);
        if (inv.s("status").equals("Paid")) throw bad("Already paid");
        if (!List.of("Bank transfer", "Card", "Cheque").contains(method)) throw bad("Choose a payment method");
        db.run("UPDATE invoices SET status='Paid', paid_at=?, method=? WHERE id=?", now(), method, iid);
        for (Long uid : c.parties(inv.l("policy_id"))) c.push(uid, "invoice", "Invoice " + inv.s("invoice_number") + " was paid (USD " + usd0(inv.dbl("amount")) + "). Thank you.");
        c.audit("pay invoice", inv.s("invoice_number")); return m("ok", true);
    }

    /** GET /api/invoices/{iid}/pdf : invoice as PDF */
    @GetMapping("/api/invoices/{iid}/pdf")
    public ResponseEntity<byte[]> invoicePdf(@PathVariable long iid) {
        List<Row> rows = rowsFor(c.need(), "AND i.id=?", iid);
        if (rows.isEmpty()) throw new ApiException(404, "Invoice not found");
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + rows.get(0).s("invoice_number") + ".pdf\"").body(pdf.makeInvoicePdf(rows.get(0)));
    }
}
