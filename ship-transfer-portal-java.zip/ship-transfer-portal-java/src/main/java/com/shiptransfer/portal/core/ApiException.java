package com.shiptransfer.portal.core;

import java.util.Map;

/** Thrown to answer with an error. Body is {"error": msg} (or a custom body for the chatbot API). */
public class ApiException extends RuntimeException {
    public final int status; public final Map<String, Object> body;
    public ApiException(int status, String msg) { super(msg); this.status = status; this.body = U.m("error", msg); }
    public ApiException(int status, Map<String, Object> body) { super("api error"); this.status = status; this.body = body; }
    public static ApiException bad(String msg) { return new ApiException(400, msg); }
}
