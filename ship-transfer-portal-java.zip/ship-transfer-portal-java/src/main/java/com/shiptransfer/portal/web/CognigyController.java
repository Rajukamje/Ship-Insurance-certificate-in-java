package com.shiptransfer.portal.web;

import com.shiptransfer.portal.config.AppProps;
import com.shiptransfer.portal.core.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/**
 * routes/cognigy.py - everything the Cognigy.AI chatbot (Insurance Risk Guardian AI) needs from the portal.
 *  1) GET /api/chat/config and /api/chat/token  -> called by the BROWSER with the normal login cookie.
 *  2) /api/bot/...  -> called by COGNIGY. Every call needs X-BOT-KEY (or X-API-Key) and, for private data, Authorization: Bearer <chat token>.
 * Business problems are answered with HTTP 200 and {"ok": false, "error": "...", "code": "..."}; only a wrong bot key gives HTTP 401.
 * The login cookie is never used on /api/bot, so these routes need no CSRF token.
 */
@RestController
public class CognigyController {
    private final Core c; private final Db db; private final AppProps props; private final ClaimsController claims; private final InvoicesController invoices;
    public CognigyController(Core c, AppProps props, ClaimsController claims, InvoicesController invoices) { this.c = c; this.db = c.db; this.props = props; this.claims = claims; this.invoices = invoices; }

    // ------------------------------------------------------------------ signed chat token: base64url(uid:issuedAt).base64url(hmac)
    private static final String BOT_USER = "bot.user";
    private static final class TokenExpired extends RuntimeException { }
    private static final class TokenBad extends RuntimeException { }

    private String sign(String payload) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256"); mac.init(new SecretKeySpec(("cognigy-chat-v1:" + props.secretKey).getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(payload.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    private String makeToken(long uid) {
        String payload = Base64.getUrlEncoder().withoutPadding().encodeToString((uid + ":" + System.currentTimeMillis() / 1000).getBytes(StandardCharsets.UTF_8));
        return payload + "." + sign(payload);
    }
    private long readToken(String token) {
        String[] parts = token.split("\\.");
        if (parts.length != 2 || !MessageDigest.isEqual(sign(parts[0]).getBytes(StandardCharsets.UTF_8), parts[1].getBytes(StandardCharsets.UTF_8))) throw new TokenBad();
        try {
            String[] v = new String(Base64.getUrlDecoder().decode(parts[0]), StandardCharsets.UTF_8).split(":");
            if (System.currentTimeMillis() / 1000 - Long.parseLong(v[1]) > props.getCognigyTtl()) throw new TokenExpired();
            return Long.parseLong(v[0]);
        } catch (TokenExpired e) { throw e; } catch (Exception e) { throw new TokenBad(); }
    }

    // ------------------------------------------------------------------ 1) browser side
    /** GET /api/chat/config : which Cognigy endpoint to open (public) */
    @GetMapping("/api/chat/config")
    public Object chatConfig() { return m("enabled", props.cognigyEnabled && !props.getCognigyEndpoint().isEmpty(), "endpoint", props.getCognigyEndpoint()); }

    /** GET /api/chat/token : signed chat ticket for the logged-in user (guests get role "guest" and no token) */
    @GetMapping("/api/chat/token")
    public Object chatToken() {
        Row u = c.current();
        if (u == null) return m("role", "guest", "name", "", "token", "", "expires_in", 0);
        return m("id", u.get("id"), "role", u.get("role"), "name", u.get("name"), "token", makeToken(u.l("id")), "expires_in", props.getCognigyTtl());
    }

    // ------------------------------------------------------------------ 2) Cognigy side
    private static Map<String, Object> ok(Object... kv) { Map<String, Object> r = m("ok", true); r.putAll(m(kv)); return r; }
    private static ApiException fail(String msg, String code) { return new ApiException(200, m("ok", false, "error", msg, "code", code)); }   // HTTP 200 on purpose

    /** Checks the bot key; with auth=true it also needs a valid chat token. Returns the user (null for guests). */
    private Row bot(HttpServletRequest req, boolean auth) {
        String sent = Optional.ofNullable(req.getHeader("X-BOT-KEY")).filter(x -> !x.isEmpty()).orElse(Optional.ofNullable(req.getHeader("X-API-Key")).orElse(""));
        if (!MessageDigest.isEqual(sent.getBytes(StandardCharsets.UTF_8), props.botKey.getBytes(StandardCharsets.UTF_8)))
            throw new ApiException(401, m("ok", false, "error", "Invalid bot key", "code", "BAD_KEY"));
        Row user = null; String head = Optional.ofNullable(req.getHeader("Authorization")).orElse("");
        String token = head.toLowerCase().startsWith("bearer ") ? head.substring(7).strip() : "";
        if (!token.isEmpty()) {
            try {
                Row u = db.one("SELECT * FROM users WHERE id=?", readToken(token));
                if (u != null && "Active".equals(u.str("status"))) user = u;
            } catch (TokenExpired e) { if (auth) throw fail("Your chat session expired. Please reload the page.", "TOKEN_EXPIRED"); }
            catch (TokenBad e) { if (auth) throw fail("Invalid chat token.", "BAD_TOKEN"); }
        }
        if (auth && user == null) throw fail("Please log in to the portal first, then I can look at your data.", "LOGIN_REQUIRED");
        return user;
    }

    private static Double num(Object v) { return toDouble(v); }

    /** GET /api/bot/me : who is chatting (guest allowed) */
    @GetMapping("/api/bot/me")
    public Object me(HttpServletRequest req) {
        Row u = bot(req, false);
        return ok("authenticated", u != null, "role", u == null ? "guest" : u.get("role"), "name", u == null ? "" : u.get("name"));
    }

    /** GET /api/bot/plans?category=Cargo : active insurance plans */
    @GetMapping("/api/bot/plans")
    public Object plans(HttpServletRequest req, @RequestParam(value = "category", required = false) String category) {
        bot(req, false); String cat = strip(category);
        List<Row> rows = cat.isEmpty() ? db.q("SELECT id, name, category, description, covers, rate, deductible FROM plans WHERE active=1 ORDER BY id")
                : db.q("SELECT id, name, category, description, covers, rate, deductible FROM plans WHERE active=1 AND LOWER(category) LIKE ? ORDER BY id", "%" + cat.toLowerCase() + "%");
        return ok("plans", rows, "count", rows.size());
    }

    /** POST /api/bot/quote : premium estimate. Body: plan_id OR plan_name, sum_insured, year_built (optional), war_strikes, bbb */
    @PostMapping("/api/bot/quote")
    public Object quote(HttpServletRequest req, @RequestBody(required = false) Map<String, Object> body) {
        Row u = bot(req, false); Map<String, Object> d = body(body); Row plan = null;
        if (s(d.get("plan_id")).matches("\\d+")) plan = db.one("SELECT * FROM plans WHERE id=? AND active=1", Integer.parseInt(s(d.get("plan_id"))));
        if (plan == null && truthy(d.get("plan_name"))) plan = db.one("SELECT * FROM plans WHERE active=1 AND LOWER(name) LIKE ? ORDER BY id", "%" + s(d.get("plan_name")).toLowerCase() + "%");
        if (plan == null) throw fail("I could not find that plan. Ask me to list the plans first.", "PLAN_NOT_FOUND");
        Double si = num(d.get("sum_insured"));
        if (si == null || si <= 0) throw fail("The sum insured must be a number above zero.", "BAD_SUM");
        Double ybd = num(d.get("year_built")); int yb = ybd == null ? 0 : ybd.intValue();
        if (yb != 0 && !(yb >= 1900 && yb <= today().getYear())) throw fail("Please give a real year built.", "BAD_YEAR");
        Long cid = u != null && u.str("role").equals("client") ? c.ids(u)[0] : null;
        Map<String, Object> out = c.quote(plan, si, yb, truthy(d.get("war_strikes")), truthy(d.get("bbb")), cid);
        out.put("plan", plan.get("name")); out.put("sum_insured", si); out.put("note", "Indicative estimate only. The final premium is set when the policy is created.");
        return ok(out.entrySet().stream().flatMap(e -> java.util.stream.Stream.of(e.getKey(), e.getValue())).toArray());
    }

    /** GET /api/bot/verify/{num} : PUBLIC certificate check (same data as the Verify page, no private information) */
    @GetMapping("/api/bot/verify/{num}")
    public Object verify(HttpServletRequest req, @PathVariable String num) {
        bot(req, false); Row r = db.one(CERT_SQL + " WHERE c.certificate_number=?", num.strip().toUpperCase());
        if (r == null) throw fail("No certificate with number " + num + " was found.", "NOT_FOUND");
        String st = cstatus(r);
        return ok("number", r.get("certificate_number"), "status", st.equals("Issued") ? "Valid" : st, "ship", r.get("ship_name"), "imo", r.get("imo"), "route", r.s("from_location") + " to " + r.s("to_location"),
                "valid_from", r.get("valid_from"), "valid_to", r.get("valid_to"), "cover", r.get("cover"));
    }

    /** GET /api/bot/certificates?number=STC-... : one certificate, or my latest 10 */
    @GetMapping("/api/bot/certificates")
    public Object certs(HttpServletRequest req, @RequestParam(value = "number", required = false) String number) {
        Row u = bot(req, true); String n = strip(number).toUpperCase();
        List<Row> rows = !n.isEmpty() ? c.certList(u, "AND c.certificate_number=?", n) : c.certList(u);
        if (n.isEmpty() && rows.size() > 10) rows = rows.subList(0, 10);
        if (!n.isEmpty() && rows.isEmpty()) throw fail("I cannot find certificate " + n + " in your account.", "NOT_FOUND");
        List<Map<String, Object>> out = new ArrayList<>();
        for (Row x : rows) {
            long left = daysLeft(x.s("valid_to"));
            out.add(m("number", x.get("certificate_number"), "status", x.get("status"), "ship", x.get("ship_name"), "imo", x.get("imo"), "policy", x.get("policy_number"), "route", x.s("from_location") + " to " + x.s("to_location"),
                    "valid_from", x.get("valid_from"), "valid_to", x.get("valid_to"), "days_left", left, "sum_insured", x.get("sum_insured"),
                    "renewal_open", (x.s("status").equals("Issued") || x.s("status").equals("Expired")) && left <= 30, "page", "certificates.html"));
        }
        return ok("certificates", out, "count", out.size());
    }

    /** GET /api/bot/policies?expiring=1 : my policies (expiring=1 -> only those that expire within 30 days) */
    @GetMapping("/api/bot/policies")
    public Object policies(HttpServletRequest req, @RequestParam(value = "expiring", required = false) String expiring) {
        Row u = bot(req, true); Core.Scope sc = c.scope(u); List<Map<String, Object>> out = new ArrayList<>();
        for (Row p : db.q(POL_SQL + " WHERE " + sc.sql() + " ORDER BY p.end_date", sc.args())) {
            String st = pstatus(p);
            if (!s(expiring).isEmpty() && !st.equals("Expiring Soon")) continue;
            out.add(m("policy_number", p.get("policy_number"), "ship", p.get("ship_name"), "imo", p.get("imo"), "plan", p.get("type"), "status", st, "start", p.get("start_date"), "end", p.get("end_date"),
                    "days_left", daysLeft(p.s("end_date")), "premium", p.get("premium"), "sum_insured", p.get("sum_insured"), "broker", p.get("broker"), "page", "policies.html"));
        }
        return ok("policies", out.size() > 15 ? out.subList(0, 15) : out, "count", out.size());
    }

    /** GET /api/bot/claims?number=CLM-... : my claims (one or the latest 10) */
    @GetMapping("/api/bot/claims")
    public Object claimsList(HttpServletRequest req, @RequestParam(value = "number", required = false) String number) {
        Row u = bot(req, true); Core.Scope sc = c.scope(u); String n = strip(number).toUpperCase();
        List<Row> rows = db.q(ClaimsController.CLAIM_SQL + "WHERE " + sc.sql() + " " + (n.isEmpty() ? "" : "AND c.claim_number=? ") + "ORDER BY c.id DESC", n.isEmpty() ? sc.args() : cat(sc.args(), n));
        if (!n.isEmpty() && rows.isEmpty()) throw fail("I cannot find claim " + n + " in your account.", "NOT_FOUND");
        List<Map<String, Object>> out = new ArrayList<>();
        for (Row x : rows.subList(0, Math.min(10, rows.size())))
            out.add(m("claim_number", x.get("claim_number"), "status", x.get("status"), "policy", x.get("policy_number"), "ship", x.get("ship_name"), "type", x.get("incident_type"), "incident_date", x.get("incident_date"),
                    "amount_claimed", x.get("amount_claimed"), "amount_approved", x.get("amount_approved"), "decision_note", x.s("decision_note"), "updated", x.get("updated_at"), "page", "claims.html"));
        return ok("claims", out, "count", rows.size(), "incident_types", CLAIM_TYPES);
    }

    /** POST /api/bot/claims : report a claim. Body: policy_number, incident_date (YYYY-MM-DD), incident_type, description, amount_claimed */
    @PostMapping("/api/bot/claims")
    public Object claimNew(HttpServletRequest req, @RequestBody(required = false) Map<String, Object> body) {
        Row u = bot(req, true); Map<String, Object> d = new HashMap<>(body(body)); Core.Scope sc = c.scope(u);
        Row p = db.one("SELECT p.id FROM policies p WHERE p.policy_number=? AND " + sc.sql(), cat(new Object[]{strip(d.get("policy_number")).toUpperCase()}, sc.args()));
        if (p == null) throw fail("I cannot find that policy number in your account.", "POLICY_NOT_FOUND");
        d.put("policy_id", p.get("id"));
        ClaimsController.SubmitResult r = claims.submit(u, d);              // exactly the same checks as the website
        if (!r.ok()) throw fail(r.error(), "CLAIM_REJECTED");
        return ok("claim_number", r.claimNumber(), "status", "Submitted", "page", "claims.html");
    }

    /** GET /api/bot/invoices?status=Unpaid : my invoices (Paid / Unpaid / Overdue) */
    @GetMapping("/api/bot/invoices")
    public Object invoicesList(HttpServletRequest req, @RequestParam(value = "status", required = false) String status) {
        Row u = bot(req, true); String st = strip(status); if (!st.isEmpty()) st = st.substring(0, 1).toUpperCase() + st.substring(1).toLowerCase();
        List<Row> rows = new ArrayList<>(); for (Row r : invoices.rowsFor(u, "")) if (st.isEmpty() || r.s("status").equals(st)) rows.add(r);
        List<Map<String, Object>> out = new ArrayList<>();
        for (Row r : rows.subList(0, Math.min(10, rows.size()))) out.add(m("invoice_number", r.get("invoice_number"), "policy", r.get("policy_number"), "amount", r.get("amount"), "status", r.get("status"), "due_date", r.get("due_date"), "page", "invoices.html"));
        return ok("invoices", out, "count", rows.size(), "total_open", round(rows.stream().filter(r -> !r.s("status").equals("Paid")).mapToDouble(r -> r.dbl("amount")).sum(), 2));
    }

    /** GET /api/bot/brokers : broker ratings (like the Find a Broker page) */
    @GetMapping("/api/bot/brokers")
    public Object brokers(HttpServletRequest req) {
        bot(req, true); List<Map<String, Object>> out = new ArrayList<>();
        for (Row b : db.q("SELECT b.id, u.name, u.company, b.category FROM brokers b JOIN users u ON u.id=b.user_id WHERE b.deleted_at IS NULL AND b.status='Active' ORDER BY b.id")) {
            Row r = db.one("SELECT ROUND(AVG(rating),1) avg, COUNT(*) n FROM reviews WHERE broker_id=?", b.get("id"));
            Row last = db.one("SELECT rating, comment FROM reviews WHERE broker_id=? ORDER BY id DESC LIMIT 1", b.get("id"));
            out.add(m("name", b.get("name"), "company", b.get("company"), "category", b.get("category"), "rating", r.dblOrNull("avg") == null ? 0.0 : r.dbl("avg"), "reviews", r.get("n"), "latest_review", last == null ? "" : last.s("comment"), "page", "directory.html"));
        }
        out.sort((a, b2) -> Double.compare((Double) b2.get("rating"), (Double) a.get("rating")));
        return ok("brokers", out);
    }

    /** GET /api/bot/documents : which required documents are still missing (clients only) */
    @GetMapping("/api/bot/documents")
    public Object documents(HttpServletRequest req) {
        Row u = bot(req, true);
        if (!u.str("role").equals("client")) throw fail("The document checklist is shown for client accounts. Brokers and admins open the Client File page.", "CLIENT_ONLY");
        long cid = c.ids(u)[0]; List<Row> docs = db.q("SELECT doc_type, status FROM documents WHERE client_id=?", cid);
        String kyc = db.one("SELECT kyc_status FROM clients WHERE id=?", cid).s("kyc_status");
        List<Map<String, Object>> req2 = new ArrayList<>(); List<String> missing = new ArrayList<>();
        for (String t : REQUIRED_DOCS) { String st = DocumentsController.best(docs, t); req2.add(m("type", t, "status", st)); if (st.equals("Missing") || st.equals("Rejected")) missing.add(t); }
        return ok("kyc_status", kyc, "required", req2, "missing", missing, "page", "clientfile.html");
    }

    /** POST /api/bot/handover : leave a message for a human (shows in the admin Inbox). Body: message, topic, email (guests only) */
    @PostMapping("/api/bot/handover")
    public Object handover(HttpServletRequest req, @RequestBody(required = false) Map<String, Object> body) {
        Row u = bot(req, false); Map<String, Object> d = body(body); String msg = strip(d.get("message"));
        String email = u != null ? u.s("email") : strip(d.get("email"));
        if (msg.length() < 10) throw fail("Please describe what you need help with (at least 10 characters).", "BAD_MESSAGE");
        if (!EMAIL.matcher(email).matches()) throw fail("Please give an email address so we can reply.", "BAD_EMAIL");
        String name = u != null ? u.s("name") : (truthy(d.get("name")) ? s(d.get("name")) : "Chatbot visitor");
        String topic = "Chatbot: " + (truthy(d.get("topic")) ? s(d.get("topic")) : "handover");
        db.run("INSERT INTO messages(name,email,topic,message,created_at) VALUES(?,?,?,?,?)", cut(name, 100), email, cut(topic, 60), cut(msg, 2000), now());
        for (Row a : db.q("SELECT id FROM users WHERE role='admin'")) c.push(a.l("id"), "contact", "Chatbot handover from " + email + ": " + cut(msg, 80));
        c.audit("chatbot handover", email, u != null ? u.l("id") : 0L);
        return ok("message", "Thank you. A team member will reply by email.");
    }
    private static String cut(String t, int n) { return t.length() > n ? t.substring(0, n) : t; }
}
