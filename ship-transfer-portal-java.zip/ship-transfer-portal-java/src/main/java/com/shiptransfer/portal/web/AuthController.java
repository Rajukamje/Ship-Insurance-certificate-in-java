package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.Map;

import static com.shiptransfer.portal.core.ApiException.bad;
import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/auth.py - Login module: register, login, logout, profile, change password. */
@RestController
public class AuthController {
    private final Core c; private final Db db;
    public AuthController(Core c) { this.c = c; this.db = c.db; }

    static String csrfToken() { byte[] b = new byte[16]; new SecureRandom().nextBytes(b); return HexFormat.of().formatHex(b); }

    /** POST /api/register : create a Client or Broker account */
    @PostMapping("/api/register")
    public Object register(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body);
        String name = strip(d.get("name")), email = strip(d.get("email")), phone = strip(d.get("phone")), pw = strip(d.get("password"));
        if (name.isEmpty()) throw bad("Full name is required");
        if (!EMAIL.matcher(email).matches()) throw bad("Enter a valid email");
        if (db.exists("SELECT 1 FROM users WHERE email=?", email.toLowerCase())) throw bad("Email already registered");
        if (!PHONE.matcher(phone).matches()) throw bad("Enter a valid phone number");
        if (!strong(pw)) throw bad(PW_MSG);
        if (!pw.equals(s(d.get("confirm")))) throw bad("Passwords do not match");
        String role = s(d.get("role"));
        if (!role.equals("client") && !role.equals("broker")) throw bad("Role must be Client or Broker");   // admins are created by admins only
        long uid = db.run("INSERT INTO users(name,email,phone,password,role,company) VALUES(?,?,?,?,?,?)", name, email.toLowerCase(), phone, DbInit.PW.encode(pw), role, s(d.get("company")));
        db.run(role.equals("client") ? "INSERT INTO clients(user_id) VALUES(?)" : "INSERT INTO brokers(user_id) VALUES(?)", uid);
        c.notify(uid, "verification", "Welcome! Email verification link (demo: account is auto-verified).");
        return m("ok", true);
    }

    /** POST /api/login : login (type must match role; 5 wrong tries lock 15 min) */
    @PostMapping("/api/login")
    public Object login(@RequestBody(required = false) Map<String, Object> body, HttpServletRequest req) {
        Map<String, Object> d = body(body);
        Row u = db.one("SELECT * FROM users WHERE email=?", strip(d.get("email")).toLowerCase());
        if (u != null && u.truthy("locked_until") && u.s("locked_until").compareTo(now()) > 0) throw new ApiException(423, "Account locked for 15 minutes after 5 failed attempts");
        if (u == null || !DbInit.PW.matches(s(d.get("password")), u.s("password"))) {
            if (u != null) {
                int f = u.i("failed") + 1;
                db.run("UPDATE users SET failed=?, locked_until=? WHERE id=?", f >= 5 ? 0 : f, f >= 5 ? LocalDateTime.now().plusMinutes(15).format(TS) : null, u.get("id"));
            }
            throw new ApiException(401, "Wrong email or password");
        }
        if (!u.s("role").equals(s(d.get("role")))) throw new ApiException(403, "Login type does not match your account role");
        if (!"Active".equals(u.str("status"))) throw new ApiException(403, "Account is inactive");
        db.run("UPDATE users SET failed=0, locked_until=NULL WHERE id=?", u.get("id"));
        HttpSession old = req.getSession(false); if (old != null) old.invalidate();          // new session at login (prevents session fixation)
        HttpSession s = req.getSession(true); s.setAttribute("uid", u.l("id")); s.setAttribute("csrf", csrfToken()); s.setMaxInactiveInterval(8 * 3600);
        c.audit("login");
        return m("user", pub(u));
    }

    static Map<String, Object> pub(Row u) {
        Map<String, Object> r = new java.util.LinkedHashMap<>();
        for (String k : new String[]{"id", "name", "email", "phone", "role", "company", "address"}) r.put(k, u.get(k));
        return r;
    }

    /** POST /api/logout : end the session */
    @PostMapping("/api/logout")
    public Object logout(HttpServletRequest req) {
        c.audit("logout"); HttpSession s = req.getSession(false); if (s != null) s.invalidate();
        return m("ok", true);
    }

    /** GET /api/me : who is logged in? Also gives the CSRF token (for every visitor). */
    @GetMapping("/api/me")
    public Object me(HttpServletRequest req) {
        Row u = c.current(); HttpSession s = req.getSession(true);
        if (s.getAttribute("csrf") == null) s.setAttribute("csrf", csrfToken());
        s.setMaxInactiveInterval(8 * 3600);
        return m("user", u == null ? null : pub(u), "csrf", s.getAttribute("csrf"));
    }

    /** PUT /api/profile : edit own profile (email and role cannot be edited) */
    @PutMapping("/api/profile")
    public Object profile(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row u = c.need();
        if (truthy(d.get("phone")) && !PHONE.matcher(s(d.get("phone"))).matches()) throw bad("Enter a valid phone number");
        db.run("UPDATE users SET name=?, phone=?, address=?, company=? WHERE id=?",
                truthy(d.get("name")) ? s(d.get("name")) : u.str("name"), truthy(d.get("phone")) ? s(d.get("phone")) : u.str("phone"), s(d.get("address")), s(d.get("company")), u.get("id"));
        c.audit("edit profile"); return m("ok", true);
    }

    /** POST /api/password : change own password */
    @PostMapping("/api/password")
    public Object password(@RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> d = body(body); Row u = c.need();
        if (!DbInit.PW.matches(s(d.get("old")), u.s("password"))) throw bad("Old password is wrong");
        if (!strong(s(d.get("new")))) throw bad(PW_MSG);
        if (!s(d.get("new")).equals(s(d.get("confirm")))) throw bad("Passwords do not match");
        db.run("UPDATE users SET password=? WHERE id=?", DbInit.PW.encode(s(d.get("new"))), u.get("id")); c.audit("change password");
        return m("ok", true);
    }
}
