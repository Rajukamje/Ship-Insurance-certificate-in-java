package com.shiptransfer.portal.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

import javax.sql.DataSource;

@Configuration
public class DbConfig {
    /** One SQLite connection for the whole app (all access is synchronized in Db). */
    @Bean
    public DataSource dataSource(AppProps p) {
        return new SingleConnectionDataSource("jdbc:sqlite:" + p.db.toAbsolutePath(), true);
    }
}
