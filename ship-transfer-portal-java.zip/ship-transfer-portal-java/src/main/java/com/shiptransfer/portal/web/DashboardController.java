package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

import static com.shiptransfer.portal.core.Core.*;
import static com.shiptransfer.portal.core.U.*;

/** routes/dashboard.py - number cards and chart data for each role. */
@RestController
public class DashboardController {
    private final Core c; private final Db db;
    public DashboardController(Core c) { this.c = c; this.db = c.db; }

    private static Map<String, Object> count(List<String> values) {
        Map<String, Object> r = new LinkedHashMap<>(); for (String v : values) r.merge(v, 1, (a, b) -> (Integer) a + 1); return r;
    }

    /** GET /api/dashboard : cards + chart data for the logged-in role */
    @GetMapping("/api/dashboard")
    public Object dashboard() {
        Row u = c.need(); c.runReminders();
        Core.Scope sc = c.scope(u); String role = u.str("role");
        List<Row> pols = db.q("SELECT p.* FROM policies p WHERE " + sc.sql(), sc.args());
        List<Row> certs = c.certList(u, "");
        List<Row> claims = db.q("SELECT c.* FROM claims c JOIN policies p ON p.id=c.policy_id WHERE " + sc.sql(), sc.args());
        List<Row> invs = db.q("SELECT i.* FROM invoices i JOIN policies p ON p.id=i.policy_id WHERE " + sc.sql(), sc.args());
        for (Row i : invs) i.put("status", istatus(i));

        Map<String, Object> cards = new LinkedHashMap<>();
        cards.put("Policies", pols.size()); cards.put("Certificates", certs.size());
        cards.put("Pending approval", certs.stream().filter(x -> x.s("status").equals("Submitted")).count());
        cards.put("Open claims", claims.stream().filter(x -> x.s("status").equals("Submitted") || x.s("status").equals("Under Review")).count());
        cards.put("Outstanding invoices (USD)", Math.round(invs.stream().filter(i -> !i.s("status").equals("Paid")).mapToDouble(i -> i.dbl("amount")).sum()));
        if (role.equals("admin")) {
            cards.put("Clients", db.count("SELECT COUNT(*) n FROM clients")); cards.put("Brokers", db.count("SELECT COUNT(*) n FROM brokers WHERE deleted_at IS NULL"));
            cards.put("Documents to verify", db.count("SELECT COUNT(*) n FROM documents WHERE status='Pending'"));
        } else if (role.equals("broker")) {
            Long b = c.ids(u)[1]; cards.put("Clients", db.count("SELECT COUNT(*) n FROM clients WHERE broker_id=?", b));
            cards.put("Documents to verify", db.count("SELECT COUNT(*) n FROM documents d JOIN clients c ON c.id=d.client_id WHERE d.status='Pending' AND c.broker_id=?", b));
        } else {
            List<Row> docs = db.q("SELECT doc_type, status FROM documents WHERE client_id=?", c.ids(u)[0]);
            cards.put("Documents missing", REQUIRED_DOCS.stream().filter(t -> docs.stream().noneMatch(d -> d.s("doc_type").equals(t) && !d.s("status").equals("Rejected"))).count());
        }
        Map<String, Double> prem = new TreeMap<>();
        for (Row p : pols) prem.merge(p.s("start_date").substring(0, 7), p.dbl("premium"), Double::sum);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("cards", cards);
        out.put("Policies by status", count(pols.stream().map(Core::pstatus).toList()));
        out.put("Claims by status", count(claims.stream().map(x -> x.s("status")).toList()));
        out.put("Invoices by status", count(invs.stream().map(x -> x.s("status")).toList()));
        out.put("Premium by month (USD)", new LinkedHashMap<String, Object>(prem));
        out.put("Claims vs premium (USD)", m("Premium", Math.round(pols.stream().mapToDouble(p -> p.dbl("premium")).sum()),
                "Claimed", Math.round(claims.stream().mapToDouble(x -> x.dbl("amount_claimed")).sum()),
                "Approved", Math.round(claims.stream().filter(x -> x.s("status").equals("Approved") || x.s("status").equals("Paid")).mapToDouble(x -> x.dbl("amount_approved")).sum())));
        Map<String, Object> perMonth = new TreeMap<>(count(certs.stream().map(x -> (x.truthy("issued_at") ? x.s("issued_at") : x.s("created_at")).substring(0, 7)).toList()));
        out.put("Certificates per month", new LinkedHashMap<>(perMonth));
        out.put("Policies by plan", count(pols.stream().map(p -> p.s("type")).toList()));
        if (role.equals("admin")) {
            Map<String, Double> top = new LinkedHashMap<>();
            for (Row p : db.q(POL_SQL)) top.merge(p.s("broker"), p.dbl("premium"), Double::sum);
            out.put("Top brokers by premium", top.entrySet().stream().sorted((a, b) -> Double.compare(b.getValue(), a.getValue())).limit(5)
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new)));
        }
        List<String> expiring = new ArrayList<>(); String limit = today().plusDays(30).toString();
        for (Row p : pols) if (pstatus(p).equals("Expiring Soon")) expiring.add("Policy " + p.s("policy_number") + " ends " + p.s("end_date"));
        for (Row x : certs) if (x.s("status").equals("Issued") && x.s("valid_to").compareTo(limit) <= 0) expiring.add("Certificate " + x.s("certificate_number") + " ends " + x.s("valid_to"));
        out.put("Expiring soon", expiring);
        return out;
    }
}
