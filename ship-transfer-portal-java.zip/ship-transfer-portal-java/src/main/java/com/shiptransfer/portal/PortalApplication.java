package com.shiptransfer.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Start the website:  mvn spring-boot:run   ->  http://localhost:5000 */
@SpringBootApplication
@EnableScheduling
public class PortalApplication {
    public static void main(String[] args) {
        // HTTPS=1 -> the login cookie is only sent over https
        if ("1".equals(System.getenv("HTTPS"))) System.setProperty("server.servlet.session.cookie.secure", "true");
        SpringApplication.run(PortalApplication.class, args);
    }
}
