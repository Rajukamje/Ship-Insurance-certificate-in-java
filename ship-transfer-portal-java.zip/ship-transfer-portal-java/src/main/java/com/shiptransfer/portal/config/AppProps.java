package com.shiptransfer.portal.config;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URI;
import java.nio.file.*;
import java.security.SecureRandom;
import java.util.HexFormat;

/** Settings (config.py). Change them with environment variables. */
@Component
public class AppProps {
    public final Path base = Paths.get(System.getProperty("user.dir"));
    @Value("${PORTAL_DB:}") String dbEnv;
    @Value("${DEMO_MODE:1}") String demo;
    @Value("${SECRET_KEY:}") String secretEnv;
    @Value("${HTTPS:0}") String https;
    @Value("${COGNIGY_ENDPOINT_URL:https://endpoint-eu-dev-cai.cognigy.cloud/8e417498d9608f45d34a32b3282fa98f641e8d9b2393e5d70af8094f70b5b575}") String cognigyEndpoint;
    @Value("${COGNIGY_ENABLED:1}") String cognigyOn;
    @Value("${COGNIGY_TOKEN_TTL:7200}") long cognigyTtl;
    @Value("${COGNIGY_API_KEY:}") String botKeyEnv;
    @Value("${RATE_LIMIT_OFF:0}") String rateOff;

    public Path db, pdfDir, upDir;
    public boolean demoMode, httpsOn, cognigyEnabled, rateLimitOff;
    public String secretKey, botKey;

    @PostConstruct
    void init() throws IOException {
        Path data = base.resolve("data"); Files.createDirectories(data);
        db = dbEnv.isBlank() ? data.resolve("portal.db") : Paths.get(dbEnv);
        Files.createDirectories(db.toAbsolutePath().getParent());
        pdfDir = data.resolve("pdfs"); upDir = data.resolve("uploads");
        rateLimitOff = rateOff.equals("1"); demoMode = demo.equals("1"); httpsOn = https.equals("1"); cognigyEnabled = cognigyOn.equals("1");
        secretKey = secretEnv.isBlank() ? fileSecret(data.resolve("secret.key"), 32) : secretEnv;     // signs chat tokens
        botKey = botKeyEnv.isBlank() ? fileSecret(data.resolve("bot.key"), 24) : botKeyEnv;           // Cognigy sends it in X-BOT-KEY
    }

    private static String fileSecret(Path f, int bytes) throws IOException {
        if (!Files.exists(f)) { byte[] b = new byte[bytes]; new SecureRandom().nextBytes(b); Files.writeString(f, HexFormat.of().formatHex(b)); }
        return Files.readString(f).trim();
    }

    public String getCognigyEndpoint() { return cognigyEndpoint; }
    public long getCognigyTtl() { return cognigyTtl; }
    public void setCognigyTtl(long t) { cognigyTtl = t; }      // tests change it

    /** Hosts the browser may talk to (Content-Security-Policy). */
    public String cognigyHosts() {
        String host = ""; try { host = URI.create(cognigyEndpoint).getHost(); } catch (Exception ignored) { }
        if (host == null || host.isEmpty()) return "https://*.cognigy.cloud wss://*.cognigy.cloud";
        String[] p = host.split("\\."); String root = p.length >= 2 ? p[p.length - 2] + "." + p[p.length - 1] : host;
        return "https://*." + root + " wss://*." + root;
    }
}
