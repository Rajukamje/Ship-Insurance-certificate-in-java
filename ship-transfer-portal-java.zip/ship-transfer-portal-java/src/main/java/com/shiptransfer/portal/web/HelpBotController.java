package com.shiptransfer.portal.web;

import com.shiptransfer.portal.core.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.regex.Pattern;

import static com.shiptransfer.portal.core.Core.pstatus;
import static com.shiptransfer.portal.core.U.*;

/** routes/helpbot.py - rule based help agent (fallback when Cognigy cannot be reached). */
@RestController
public class HelpBotController {
    private static final String[][] HELP = {
        {"claim", "To report a loss open Claims > Report a claim, choose the policy, the incident date, type and amount. Upload evidence in My Documents. An admin reviews it: Under Review, then Approved or Rejected, then Paid."},
        {"renew", "Open Policies (or Certificates) and click Renew. Renewal opens 60 days before a policy and 30 days before a certificate expires. You also get notifications 30, 15 and 7 days before."},
        {"invoice|pay|bill", "Open Invoices to see what is due. Click Pay, choose a method, and download the invoice PDF. Overdue invoices create a notification."},
        {"document|upload|kyc", "Open My Documents (clients) or the client file (brokers). Required: ID / company registration, ship registry, class certificate and survey report. Your broker verifies each one."},
        {"broker|review|rating", "Open Find a Broker to compare ratings and reviews, choose your broker, and rate him after working together."},
        {"plan|cover|icc|insurance type", "Open Insurance Plans to compare Hull, Cargo ICC A/B/C, Liability, Builder's Risk and Inland Marine, and use the quote calculator."},
        {"imo", "An IMO number is the unique 7-digit identification number of a ship."},
        {"sum insured", "Sum insured is the maximum amount the insurance covers."}, {"premium", "Premium is the price paid for the insurance."},
        {"deductible", "The deductible is the part of a loss you pay yourself."},
        {"pending|status|submitted", "New requests are 'Submitted' until an admin approves them. Then they become 'Issued' and the PDF is available."},
        {"create|request|how", "Open Certificates > Request Certificate, pick a policy, enter route, dates and sum insured. An admin approves it and the PDF with QR code is generated."},
        {"verify|qr", "Scan the QR code or open Verify Certificate and type the number. It shows Valid, Expired or Cancelled."},
        {"policy", "A policy is the insurance contract. One policy can have many certificates."}};
    private final Core c; private final Db db;
    public HelpBotController(Core c) { this.c = c; this.db = c.db; }

    /** POST /api/help : help agent answer */
    @PostMapping("/api/help")
    public Object help(@RequestBody(required = false) Map<String, Object> body) {
        String msg = s(body(body).get("message")).toLowerCase(); Row u = c.current();
        if (msg.contains("expir")) {
            if (u == null) return m("reply", "Please log in first so I can check your policies.");
            Core.Scope sc = c.scope(u); List<String> rows = new ArrayList<>();
            for (Row p : db.q("SELECT p.* FROM policies p WHERE " + sc.sql(), sc.args())) if (pstatus(p).equals("Expiring Soon")) rows.add(p.s("policy_number") + " (" + p.s("end_date") + ")");
            return m("reply", "Expiring within 30 days: " + (rows.isEmpty() ? "none." : String.join(", ", rows)));
        }
        for (String[] h : HELP) if (Pattern.compile(h[0]).matcher(msg).find()) return m("reply", h[1]);
        return m("reply", "I'm not sure about that. I'll hand you to a human: support@example.com. I can never promise approval of a claim or certificate.");
    }
}
