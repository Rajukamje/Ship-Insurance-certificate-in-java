/* charts.js - small SVG / CSS charts for the dashboard (no external library needed): donut, pie, columns, bars, line */

const PALETTE = ["#2d62c4", "#12b5cb", "#f5a524", "#7c5cff", "#e5484d", "#2ea36b"];
const chartCard = (title, inner) => `<div class="card"><b>${title}</b><div style="margin-top:10px">${inner}</div></div>`;

// Donut chart: data = {label: number}
function donut(title, data) {
  const entries = Object.entries(data), total = entries.reduce((a, [, v]) => a + v, 0);
  if (!total) return chartCard(title, "<small>No data yet</small>");
  let offset = 0;
  const arcs = entries.map(([, v], i) => {
    const pct = v / total * 100;                                  // share of the circle (circumference = 100)
    const arc = `<circle r="15.9155" cx="21" cy="21" fill="none" stroke="${PALETTE[i % 6]}" stroke-width="5" stroke-dasharray="${pct} ${100 - pct}" stroke-dashoffset="${-offset}" transform="rotate(-90 21 21)"/>`;
    offset += pct; return arc;
  }).join("");
  const legend = entries.map(([k, v], i) => `<li><span class="dot" style="background:${PALETTE[i % 6]}"></span>${esc(k)}: <b>${v}</b></li>`).join("");
  return chartCard(title, `<div class="donut"><svg viewBox="0 0 42 42" width="130"><circle r="15.9155" cx="21" cy="21" fill="none" stroke="#e6eaf3" stroke-width="5"/>${arcs}
    <text x="21" y="23" text-anchor="middle" font-size="7" font-weight="700" fill="currentColor">${total}</text></svg><ul>${legend}</ul></div>`);
}

// Horizontal bars: data = {label: number}
function bars(title, data) {
  const max = Math.max(1, ...Object.values(data));
  return chartCard(title, Object.entries(data).map(([k, v]) => `<div class="bar"><span>${esc(k)}</span><i style="width:${v / max * 60 + 2}%"></i> ${Number(v).toLocaleString()}</div>`).join("") || "<small>No data yet</small>");
}

// Line chart over months: data = {"2026-09": number, ...}
function line(title, data) {
  const e = Object.entries(data); if (e.length < 2) return bars(title, data);
  const max = Math.max(1, ...e.map(x => x[1])), W = 300, H = 110;
  const pts = e.map(([, v], i) => [10 + i * (W - 20) / (e.length - 1), H - 10 - v / max * (H - 30)]);
  return chartCard(title, `<svg viewBox="0 0 ${W} ${H + 14}" width="100%"><polyline fill="none" stroke="#2d62c4" stroke-width="3" points="${pts.map(p => p.join(",")).join(" ")}"/>
    ${pts.map((p, i) => `<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="#12b5cb"/><text x="${p[0]}" y="${H + 10}" font-size="8" text-anchor="middle" fill="currentColor">${e[i][0].slice(2)}</text>`).join("")}</svg>`);
}

// Pie chart (full circle): data = {label: number}
function pie(title, data) {
  const entries = Object.entries(data).filter(([, v]) => v > 0), total = entries.reduce((a, [, v]) => a + v, 0);
  if (!total) return chartCard(title, "<small>No data yet</small>");
  let a0 = -Math.PI / 2;
  const point = a => `${(21 + 20 * Math.cos(a)).toFixed(3)} ${(21 + 20 * Math.sin(a)).toFixed(3)}`;
  const slices = entries.map(([, v], i) => {
    const a1 = a0 + v / total * 2 * Math.PI;
    const s = entries.length === 1 ? `<circle cx="21" cy="21" r="20" fill="${PALETTE[0]}"/>`
      : `<path d="M21 21 L${point(a0)} A20 20 0 ${v / total > 0.5 ? 1 : 0} 1 ${point(a1)} Z" fill="${PALETTE[i % 6]}" stroke="#fff" stroke-width=".5"/>`;
    a0 = a1; return s;
  }).join("");
  const legend = entries.map(([k, v], i) => `<li><span class="dot" style="background:${PALETTE[i % 6]}"></span>${esc(k)}: <b>${v.toLocaleString()}</b> (${Math.round(v / total * 100)}%)</li>`).join("");
  return chartCard(title, `<div class="donut"><svg viewBox="0 0 42 42" width="130">${slices}</svg><ul>${legend}</ul></div>`);
}

// Column chart (vertical bars): data = {label: number}
function columns(title, data) {
  const e = Object.entries(data); if (!e.length) return chartCard(title, "<small>No data yet</small>");
  const max = Math.max(1, ...e.map(x => x[1])), W = 300, H = 130, bw = Math.min(46, (W - 20) / e.length - 8);
  const cols = e.map(([k, v], i) => {
    const h = v / max * (H - 35), x = 10 + i * ((W - 20) / e.length) + 4;
    return `<rect x="${x}" y="${H - 20 - h}" width="${bw}" height="${h}" rx="4" fill="${PALETTE[i % 6]}"/>
      <text x="${x + bw / 2}" y="${H - 24 - h}" font-size="8" text-anchor="middle" fill="currentColor">${Number(v).toLocaleString()}</text>
      <text x="${x + bw / 2}" y="${H - 6}" font-size="8" text-anchor="middle" fill="currentColor">${esc(k.length > 9 ? k.slice(2, 9) : k)}</text>`;
  }).join("");
  return chartCard(title, `<svg viewBox="0 0 ${W} ${H}" width="100%">${cols}</svg>`);
}
