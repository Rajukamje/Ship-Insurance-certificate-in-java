/* help-bot.js - floating help chat bubble (bottom right). Answers come from POST /api/help (portal/routes/helpbot.py).
   Since the Cognigy chatbot was added, js/cognigy-bot.js loads this file ONLY as a fallback when Cognigy cannot be reached. */

document.body.insertAdjacentHTML("beforeend", `
  <button id="chatb" onclick="toggleChat()" title="Help agent">?</button>
  <div id="chat"><b>Help agent</b>
    <div id="msgs"><p>Hi! Ask me about IMO numbers, certificates, statuses or expiring policies.</p></div>
    <form onsubmit="sendHelp(event)" style="display:flex;gap:6px"><input id="hq" placeholder="Ask something..." style="flex:1"><button>Send</button></form>
  </div>`);

// Open / close the chat window
function toggleChat() { const c = $("#chat"); c.style.display = c.style.display === "block" ? "none" : "block"; }

// Send the question to the server and show the answer
async function sendHelp(e) {
  e.preventDefault();
  const q = $("#hq").value.trim(); if (!q) return;
  $("#hq").value = "";
  const box = $("#msgs");
  box.innerHTML += `<p class="me">${esc(q)}</p>`;
  try { box.innerHTML += `<p>${esc((await api("/api/help", "POST", { message: q })).reply)}</p>`; }
  catch (x) { box.innerHTML += "<p>Sorry, something went wrong.</p>"; }
  box.scrollTop = box.scrollHeight;
}
