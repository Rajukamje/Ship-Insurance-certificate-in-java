/* layout.js - loaded LAST on every page.
   1) asks the server who is logged in (+ gets the CSRF token)   2) redirects when the page is not allowed
   3) draws the sidebar, the HEADER (menus, search, bell, login) and the FOOTER   4) starts the page by calling initPage() */

let ME = null;   // logged-in user {id, name, email, role, ...} or null. Page scripts use it.

// Sidebar menu: [page name, label]. The page name is the HTML file (home = index.html).
const MENU = {
  guest:  [["home", "🏠 Home"], ["plans", "💼 Insurance Plans"], ["verify", "✅ Verify Certificate"], ["insights", "💡 Risk Insights"], ["contact", "✉️ Contact"], ["login", "🔐 Login"], ["register", "📝 Register"]],
  client: [["dashboard", "📊 Dashboard"], ["plans", "💼 Insurance Plans"], ["policies", "📑 My Policies"], ["certificates", "📄 My Certificates"], ["claims", "🧾 Claims"], ["invoices", "💳 Invoices"], ["clientfile", "📎 My Documents"], ["directory", "⭐ Find a Broker"], ["notifications", "🔔 Notifications"], ["profile", "👤 Profile"]],
  broker: [["dashboard", "📊 Dashboard"], ["clients", "🧑‍💼 My Clients"], ["plans", "💼 Insurance Plans"], ["policies", "📑 Policies"], ["certificates", "📄 Certificates"], ["claims", "🧾 Claims"], ["invoices", "💳 Invoices"], ["directory", "⭐ Broker Reviews"], ["records", "🗂️ Records"], ["notifications", "🔔 Notifications"], ["profile", "👤 Profile"]],
  admin:  [["dashboard", "📊 Dashboard"], ["brokers", "🤝 Brokers"], ["clients", "🧑‍💼 Clients"], ["plans", "💼 Insurance Plans"], ["policies", "📑 Policies"], ["certificates", "📄 Certificates"], ["claims", "🧾 Claims"], ["invoices", "💳 Invoices"], ["directory", "⭐ Broker Reviews"], ["records", "🗂️ Records"], ["inbox", "📥 Inbox"], ["audit", "🛡️ Audit Log"], ["notifications", "🔔 Notifications"], ["profile", "👤 Profile"]]
};
const HIDDEN = { broker: ["clientfile"], admin: ["clientfile"] };   // pages opened from a link (client file), not from the menu
const fileOf = name => name === "home" ? "index.html" : name + ".html";

// ---- Dark mode: remembered in the browser (localStorage may be blocked, so we guard it) ----
function setDark(on) { document.body.classList.toggle("dark", on); try { localStorage.setItem("dark", on ? "1" : "0"); } catch (e) {} }
function toggleDark() { setDark(!document.body.classList.contains("dark")); }
try { setDark(localStorage.getItem("dark") === "1"); } catch (e) {}

// ---- Sidebar (left) ----
function drawSidebar(page) {
  const items = MENU[ME ? ME.role : "guest"];
  $("#side").innerHTML = `<h2>ALLIANZ</h2><small>ShipTransfer Portal</small>` +
    items.map(([name, label]) => `<a href="${fileOf(name)}" class="${name === page ? "on" : ""}">${label}</a>`).join("") +
    (ME ? `<div class="who"><div class="avatar">${esc(ME.name[0].toUpperCase())}</div><div>${esc(ME.name)}<br><small style="margin:0">${ME.role}</small></div></div><a href="#" onclick="logout();return false">🚪 Logout</a>` : "");
}

// ---- Header (top): menus with drop-downs, certificate search, notification bell, dark mode, login / user ----
function drawHeader() {
  const dd = (label, href, links) => `<div class="dd"><a href="${href}">${label} ▾</a><div class="menu">${links.map(([h, t]) => `<a href="${h}">${t}</a>`).join("")}</div></div>`;
  $("#top").innerHTML = `<div class="topbar">
    <nav class="topnav">
      <a href="index.html">Home</a>
      ${dd("Solutions", "plans.html", [["plans.html?cat=Hull", "⚓ Hull & Machinery"], ["plans.html?cat=Cargo", "📦 Cargo (ICC A / B / C)"], ["plans.html?cat=Liability", "⚖️ Marine Liability"], ["plans.html?cat=Builders", "🏗️ Builder's Risk"], ["plans.html?cat=Inland", "🚚 Inland Marine"]])}
      ${dd("Services", "dashboard.html", [["claims.html", "🧾 Claims"], ["policies.html", "🔁 Policies &amp; Renewals"], ["invoices.html", "💳 Invoices"], ["clientfile.html", "📎 Documents"], ["directory.html", "⭐ Broker reviews"]])}
      ${dd("Insights", "insights.html", [["insights.html", "💡 Risk tips"], ["verify.html", "✅ Verify a certificate"]])}
      <a href="contact.html">Contact</a>
    </nav>
    <form class="search" onsubmit="return doSearch(event)"><input id="q" placeholder="🔎 Verify certificate no. (STC-…)"></form>
    ${ME ? `<a class="bell" href="notifications.html" title="Notifications">🔔<span id="bellCount" class="count" style="display:none"></span></a>` : ""}
    <button class="icon" onclick="toggleDark()" title="Dark / light mode">🌙</button>
    ${ME ? `<a class="chip" href="profile.html">${esc(ME.name)}</a>` : `<a class="chip" href="login.html">Login</a><a class="chip solid" href="register.html">Register</a>`}
  </div>
  <div id="crumbs"><a href="index.html">Home</a> › <b>${esc(document.body.dataset.title || "")}</b></div>`;
  if (ME) api("/api/notifications?count=1").then(r => { if (r.count) { const b = $("#bellCount"); b.textContent = r.count; b.style.display = "inline-block"; } }).catch(() => {});
}
function doSearch(e) { e.preventDefault(); const v = $("#q").value.trim(); if (v) location.href = "verify.html?n=" + encodeURIComponent(v); return false; }

// ---- Footer: link columns, newsletter sign-up, legal links ----
function drawFooter() {
  const col = (title, links) => `<div><h4>${title}</h4>${links.map(([h, t]) => `<a href="${h}">${t}</a>`).join("")}</div>`;
  $("#foot").innerHTML = `<div class="foot-grid">
    ${col("What we offer", [["plans.html", "Insurance plans"], ["claims.html", "Claims"], ["policies.html", "Policies &amp; renewals"], ["invoices.html", "Invoices"]])}
    ${col("Featured", [["verify.html", "Verify a certificate"], ["directory.html", "Find a broker"], ["insights.html", "Risk insights"], ["notifications.html", "Notifications"]])}
    ${col("More", [["index.html", "About the portal"], ["contact.html", "Contact"], ["index.html#faq", "Questions (FAQ)"], ["register.html", "Create an account"]])}
    <div><h4>Stay up to date</h4><form onsubmit="subscribe(event)" class="news"><input id="nl" type="email" placeholder="Your email" required><button>Subscribe</button></form><small>Risk tips and product news. Unsubscribe any time.</small></div>
  </div>
  <div class="legal"><a href="privacy.html">Privacy notice</a><a href="terms.html">Terms of use</a><a href="contact.html">Contact</a><a href="contact.html?topic=concern">Report a concern</a><span>© 2026 ShipTransfer Portal - demo project</span></div>`;
}
const subscribe = e => { e.preventDefault(); act(async () => { await api("/api/newsletter", "POST", { email: $("#nl").value }); $("#nl").value = ""; }, "Subscribed. Thank you!"); };

async function logout() { try { window.shipBotReset && window.shipBotReset(); } catch (e) {} await api("/api/logout", "POST"); location.href = "index.html"; }   // shipBotReset: js/cognigy-bot.js forgets the chat

// ---- Start: runs once when the page has loaded ----
(async function start() {
  const me = await api("/api/me");                       // who is logged in + CSRF token
  ME = me.user; CSRF = me.csrf;
  const page = document.body.dataset.page;               // set in each HTML file: <body data-page="policies">
  const isPublic = document.body.dataset.public === "true";
  if (!ME && !isPublic) return location.href = "login.html";                                   // must log in first
  const allowed = ME ? MENU[ME.role].map(m => m[0]).concat(HIDDEN[ME.role] || []) : [];
  if (ME && !isPublic && !allowed.includes(page)) return location.href = "dashboard.html";     // role not allowed (server checks too)
  drawSidebar(page); drawHeader(); drawFooter();
  if (typeof initPage === "function") {
    try { await initPage(); } catch (e) { $("#main").innerHTML = `<div class="card">${esc(e.message)}</div>`; }
  }
})();
