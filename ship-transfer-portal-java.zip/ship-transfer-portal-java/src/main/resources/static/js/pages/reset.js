/* pages/reset.js - Reset password: the token comes from the link (?token=...) */
const doReset = d => act(async () => {
  await api("/api/reset", "POST", { ...d, token: new URLSearchParams(location.search).get("token") });
  location.href = "login.html";
}, "Password changed. Please log in.");
