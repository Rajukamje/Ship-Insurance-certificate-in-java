/* pages/certificates.js - Certificates: request, approve + issue (admin), Email / Download / Copy / Print, Renew, details */

let CERTS = [];

async function initPage() {
  const [rows, pols] = await Promise.all([api("/api/certificates"), api("/api/policies")]);
  CERTS = rows;
  const open = pols.filter(p => !["Expired", "Cancelled"].includes(p.status));
  $("#main").innerHTML = `<h1>Certificates</h1>
    <div class="card"><details><summary><b>+ Request certificate</b></summary><form class="f" onsubmit="sub(event, reqCert)">
      <label>Policy<select name="policy_id">${options(open.map(p => [p.id, p.policy_number + " - " + p.ship_name]))}</select></label>
      <label>From<input name="from_location" required></label><label>To<input name="to_location" required></label><label>Valid from<input name="valid_from" type="date" required></label><label>Valid to<input name="valid_to" type="date" required></label>
      <label>Sum insured (USD)<input name="sum_insured" type="number" required></label><label>Mode<input name="mode" value="Self-propelled, with cargo on board"></label><button>Submit request</button></form></details></div>
    <div class="card">` + table(["Number", "Ship", "Client", "Route", "Valid", "Sum insured", "Status", "Actions"], rows, c => {
      const left = daysLeft(c.valid_to), issued = c.certificate_number && c.status !== "Cancelled";
      return `<tr><td><a href="#" onclick="detail(${c.id});return false">${c.certificate_number || "(pending)"}</a></td><td>${esc(c.ship_name)}</td><td>${esc(c.insured)}</td><td>${esc(c.from_location)} to ${esc(c.to_location)}</td>
      <td>${c.valid_from} to ${c.valid_to}${c.status === "Issued" && left <= 30 ? `<br><small>⏰ ${left} days left</small>` : ""}</td><td>${money(c.sum_insured)}</td><td>${badge(c.status)}</td><td>
      ${issued ? `<button class="sm alt" onclick="emailCert(${c.id})">Email</button><button class="sm alt" onclick="location='/api/certificates/${c.id}/pdf?dl=1'">Download</button><button class="sm alt" onclick="copyCert('${c.certificate_number}')">Copy</button><button class="sm alt" onclick="printCert(${c.id})">Print</button>` : ""}
      ${c.certificate_number && (c.status === "Expired" || (c.status === "Issued" && left <= 30)) ? `<button class="sm" onclick="renewCert(${c.id})">🔁 Renew</button>` : ""}
      ${ME.role === "admin" && c.status === "Submitted" ? `<button class="sm" onclick="issue(${c.id})">Approve &amp; Issue</button>` : ""}
      ${ME.role === "admin" && ["Submitted", "Issued"].includes(c.status) ? `<button class="sm red" onclick="cancelCert(${c.id})">Cancel</button>` : ""}</td></tr>`; }) + `</div>`;
}

const reqCert = d => act(async () => { await api("/api/certificates", "POST", d); location.reload(); }, "Request submitted. An admin will review it.");
const issue = id => act(async () => { await api(`/api/certificates/${id}/issue`, "POST"); location.reload(); }, "Certificate issued");   // server: number + PDF + QR, then locked
const cancelCert = id => confirm("Cancel this certificate?") && act(async () => { await api(`/api/certificates/${id}/cancel`, "POST"); location.reload(); }, "Cancelled");
const renewCert = id => confirm("Request a renewal with the next dates?") && act(async () => { await api(`/api/certificates/${id}/renew`, "POST"); location.reload(); }, "Renewal requested. An admin will review it.");
const emailCert = id => { const to = prompt("Send the certificate PDF to which email?"); if (to) act(async () => toast((await api(`/api/certificates/${id}/email`, "POST", { to })).message)); };
const copyCert = n => act(() => navigator.clipboard.writeText(`${n} - ${location.origin}/verify.html?n=${n}`), "Number and verification link copied");
const printCert = id => { const f = document.createElement("iframe"); f.style.display = "none"; f.src = `/api/certificates/${id}/pdf`; f.onload = () => f.contentWindow.print(); document.body.append(f); };
function detail(id) {
  const c = CERTS.find(x => x.id == id);
  $("#dlg").innerHTML = `<h2>${c.certificate_number || "Pending request"} ${badge(c.status)}</h2><p>Insured: ${esc(c.insured)}<br>Broker: ${esc(c.broker)}<br>Policy: ${c.policy_number}<br>
    Ship: ${esc(c.ship_name)}, IMO ${c.imo}, ${esc(c.flag)}, ${esc(c.ship_type)}, ${c.tonnage} GT<br>Transfer: ${esc(c.from_location)} to ${esc(c.to_location)}<br>Valid: ${c.valid_from} to ${c.valid_to}<br>
    Cover: ${esc(c.cover)}<br>Sum insured: ${money(c.sum_insured)} | Deductible: ${money(c.deductible)} | Premium: ${money(c.premium)}<br>${c.issued_by ? `Issued by ${esc(c.issued_by)} on ${c.issued_at}` : ""}</p>
    <button onclick="$('#dlg').close()">Close</button>`;
  $("#dlg").showModal();
}
