/* pages/contact.js - Contact form: POST /api/contact (admins read it in the Inbox) */
const topic = new URLSearchParams(location.search).get("topic");
if (topic === "concern") document.addEventListener("DOMContentLoaded", () => { const s = document.querySelector("select[name=topic]"); if (s) s.value = "Report a concern"; });
const doContact = (d, f) => act(async () => { await api("/api/contact", "POST", d); f.reset(); }, "Message sent. Thank you!");
