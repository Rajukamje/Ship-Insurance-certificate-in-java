/* pages/verify.js - Verify page (public): type or scan a certificate number, shows Valid / Expired / Cancelled. Draws into <main id="main">. */
// Builds the HTML of this page (ME = logged-in user, defined in layout.js; helpers table/badge/money/esc/api come from api.js)
const render = async(num)=>{
  let res="";if(num){try{const v=await api("/api/verify/"+encodeURIComponent(num));
    res=`<div class="card"><h2>${badge(v.status)} ${esc(v.number)}</h2>Ship: ${esc(v.ship)} (IMO ${esc(v.imo)})<br>Route: ${esc(v.from)} to ${esc(v.to)}<br>Valid: ${v.valid_from} to ${v.valid_to}<br>Cover: ${esc(v.cover)}</div>`}
    catch(e){res=`<div class="card">${badge("Cancelled")} ${esc(e.message)}</div>`}}
  return `<h1>Verify Certificate</h1><div class="card"><form onsubmit="event.preventDefault();location.href='verify.html?n='+encodeURIComponent(this.n.value.trim())"><input name="n" value="${esc(num||"")}" placeholder="STC-2026-000001" size=26> <button>Verify</button></form></div>`+res;};

// layout.js calls this after the login check passed
async function initPage() { document.getElementById("main").innerHTML = await render(new URLSearchParams(location.search).get("n")); }
