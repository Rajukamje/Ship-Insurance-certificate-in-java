/* pages/audit.js - Audit log page (Admin only), read-only. Draws into <main id="main">. */
// Builds the HTML of this page (ME = logged-in user, defined in layout.js; helpers table/badge/money/esc/api come from api.js)
const render = async()=>`<h1>Audit Log</h1><div class="card">`+table(["Time","User","Action","Target"],await api("/api/audit"),a=>`<tr><td>${a.time}</td><td>${esc(a.user)}</td><td>${esc(a.action)}</td><td>${esc(a.target)}</td></tr>`)+`</div>`;

// layout.js calls this after the login check passed
async function initPage() { document.getElementById("main").innerHTML = await render(); }
