/* pages/register.js - Register page. The page HTML is written directly in register.html */

// Register form: POST /api/register, then open the login page
const doRegister=d=>act(async()=>{await api("/api/register","POST",d);location.href="login.html"},"Registered! Please log in.");
