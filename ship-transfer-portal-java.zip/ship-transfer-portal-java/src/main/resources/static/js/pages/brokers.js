/* pages/brokers.js - Brokers page (Admin only): add, edit, soft delete. Draws into <main id="main">. */
// Builds the HTML of this page (ME = logged-in user, defined in layout.js; helpers table/badge/money/esc/api come from api.js)
const render = async()=>{
  const rows=await api("/api/brokers");
  return `<h1>Brokers</h1><div class="card"><details><summary><b>+ Add broker</b></summary><form class="f" onsubmit="sub(event,addBroker)"><label>Name<input name="name" required></label><label>Email<input name="email" type="email" required></label>
  <label>Company<input name="company"></label><label>Category<select name="category"><option>Marine</option><option>Cargo</option><option>Hull</option></select></label><label>Temp password<input name="password" required></label><button>Add</button></form></details></div>
  <div class="card">`+table(["Name","Company","Email","Category","Status","Actions"],rows,b=>`<tr><td>${esc(b.name)}</td><td>${esc(b.company)}</td><td>${esc(b.email)}</td><td>${b.category}</td><td>${badge(b.status)}</td>
  <td><button class="sm alt" onclick="editBroker(${b.id},'${b.category}','${b.status}')">Edit</button><button class="sm red" onclick="delBroker(${b.id})">Delete</button></td></tr>`)+`</div>`;};

// layout.js calls this after the login check passed
async function initPage() { document.getElementById("main").innerHTML = await render(); }

// Add-broker form: POST /api/brokers
const addBroker=d=>act(async()=>{await api("/api/brokers","POST",d);location.reload()},"Broker added");

// Edit a broker (category / status) with simple prompts
const editBroker=(id,cat,st)=>{const category=prompt("Category (Marine / Cargo / Hull)",cat);if(!category)return;const status=prompt("Status (Active / Inactive)",st);status&&act(async()=>{await api(`/api/brokers/${id}`,"PUT",{category,status});location.reload()},"Broker updated")};

// Soft delete: hides the broker, history stays
const delBroker=id=>confirm("Delete this broker? (hidden, history is kept)")&&act(async()=>{await api(`/api/brokers/${id}`,"DELETE");location.reload()},"Broker deleted");
