/* pages/records.js - Records page: search, filter and CSV export. Draws into <main id="main">. */
const QS = new URLSearchParams(location.search);   // ?q=..&status=.. in the address bar

// Builds the HTML of this page (ME = logged-in user, defined in layout.js; helpers table/badge/money/esc/api come from api.js)
const render = async()=>{
  const p=new URLSearchParams({q:QS.get("q")||"",status:QS.get("status")||""}), rows=await api("/api/records?"+p);
  return `<h1>Insurance Records</h1><div class="card"><form class="f" onsubmit="sub(event,d=>{location.search="?q="+encodeURIComponent(d.q)+"&status="+encodeURIComponent(d.status)})"><label>Search<input name="q" value="${esc(QS.get("q")||"")}"></label>
  <label>Status<select name="status"><option value="">All</option>${["Submitted","Issued","Expired","Cancelled"].map(s=>`<option ${s==QS.get("status")?"selected":""}>${s}</option>`)}</select></label><button>Filter</button>
  <a class="btn" style="padding:9px 12px;border-radius:8px;text-decoration:none;text-align:center" href="/api/records.csv?${p}">Export CSV</a></form></div>
  <div class="card">`+table(["Certificate","Policy","Ship","Insured","Broker","Route","Sum insured","Status"],rows,c=>`<tr><td>${c.certificate_number||"-"}</td><td>${c.policy_number}</td><td>${esc(c.ship_name)}</td><td>${esc(c.insured)}</td><td>${esc(c.broker)}</td><td>${esc(c.from_location)} to ${esc(c.to_location)}</td><td>${money(c.sum_insured)}</td><td>${badge(c.status)}</td></tr>`)+`</div>`;};

// layout.js calls this after the login check passed
async function initPage() { document.getElementById("main").innerHTML = await render(); }
