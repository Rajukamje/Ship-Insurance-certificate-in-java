/* api.js - small helpers shared by every page (loaded first) */

const $ = s => document.querySelector(s);                       // short for document.querySelector

// Make text safe before putting it into HTML (prevents HTML injection)
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// Anti-CSRF token: given by the server in /api/me (see layout.js) and sent back with every change request
let CSRF = "";

// Call the backend. Returns the JSON answer, or throws Error(message) when the server says error.
async function api(url, method = "GET", body) {
  const headers = { "Content-Type": "application/json" };
  if (method !== "GET") headers["X-CSRF-Token"] = CSRF;
  const r = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "Something went wrong");
  return d;
}

// Upload a file (FormData) to the backend
async function upload(url, form) {
  const r = await fetch(url, { method: "POST", headers: { "X-CSRF-Token": CSRF }, body: form });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "Upload failed");
  return d;
}

// Small pop-up message (green = ok, red = error)
function toast(msg, isError) {
  const t = $("#toast");
  t.textContent = msg; t.style.background = isError ? "#b3261e" : "#1b7f3b"; t.style.display = "block";
  setTimeout(() => t.style.display = "none", 3500);
}

// Run an async action; show the error as a toast, or okMsg when it worked
const act = async (fn, okMsg) => { try { const r = await fn(); if (okMsg) toast(okMsg); return r; } catch (e) { toast(e.message, true); } };

// Form submit helper: stops the page reload and gives you the form values as an object
const sub = (e, fn) => { e.preventDefault(); fn(Object.fromEntries(new FormData(e.target)), e.target); };

// Small HTML builders
const badge = s => `<span class="badge ${esc(s)}">${esc(s)}</span>`;                  // coloured status label
const money = n => "USD " + Number(n).toLocaleString();                                // 12500000 -> USD 12,500,000
const stars = n => "★".repeat(Math.round(n)) + "☆".repeat(5 - Math.round(n));         // 4.2 -> ★★★★☆
const daysLeft = date => Math.round((new Date(date) - new Date(new Date().toDateString())) / 864e5);
// table(headings, rows, rowFunction) -> HTML table; rowFunction(row) returns one <tr>
const table = (cols, rows, cell) =>
  `<div style="overflow-x:auto"><table><tr>${cols.map(c => `<th>${c}</th>`).join("")}</tr>${rows.map(cell).join("") || `<tr><td colspan=${cols.length}>No data yet</td></tr>`}</table></div>`;
// <option> list from an array of strings or [value,label]
const options = (items, selected) => items.map(i => { const [v, l] = Array.isArray(i) ? i : [i, i]; return `<option value="${esc(v)}" ${v == selected ? "selected" : ""}>${esc(l)}</option>`; }).join("");
