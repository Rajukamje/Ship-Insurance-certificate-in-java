package com.shiptransfer.portal;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shiptransfer.portal.config.AppProps;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.nio.file.Files;
import java.time.LocalDate;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

/** Tests for the chatbot API (port of tests/test_cognigy.py). Uses a temporary database, your real data is untouched. */
@SpringBootTest(properties = {"COGNIGY_API_KEY=test-key", "SECRET_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", "RATE_LIMIT_OFF=1"})
@AutoConfigureMockMvc
class BotApiTest {
    static { try { System.setProperty("PORTAL_DB", Files.createTempDirectory("portal-test").resolve("t.db").toString()); } catch (Exception e) { throw new RuntimeException(e); } }

    @Autowired MockMvc mvc;
    @Autowired AppProps props;
    final ObjectMapper om = new ObjectMapper();

    record Login(MockHttpSession session, String token) { }

    JsonNode json(MockHttpServletRequestBuilder rb) throws Exception { return om.readTree(mvc.perform(rb).andReturn().getResponse().getContentAsString()); }
    int status(MockHttpServletRequestBuilder rb) throws Exception { return mvc.perform(rb).andReturn().getResponse().getStatus(); }
    MockHttpServletRequestBuilder key(MockHttpServletRequestBuilder rb) { return rb.header("X-BOT-KEY", "test-key"); }
    MockHttpServletRequestBuilder auth(MockHttpServletRequestBuilder rb, String token) { return key(rb).header("Authorization", "Bearer " + token); }
    MockHttpServletRequestBuilder post(String url, Object body, String token) throws Exception {
        return auth(post(url), token).contentType(MediaType.APPLICATION_JSON).content(om.writeValueAsString(body));
    }

    Login login(String email, String pw, String role) throws Exception {
        MockHttpSession s = new MockHttpSession();
        String csrf = json(get("/api/me").session(s)).get("csrf").asText();
        int code = status(post("/api/login").session(s).header("X-CSRF-Token", csrf).contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(Map.of("email", email, "password", pw, "role", role))));
        assertEquals(200, code);
        return new Login(s, json(get("/api/chat/token").session(s)).get("token").asText());
    }

    @Test void configAndGuestToken() throws Exception {
        assertTrue(json(get("/api/chat/config")).get("enabled").asBoolean());
        JsonNode t = json(get("/api/chat/token")); assertEquals("guest", t.get("role").asText()); assertEquals("", t.get("token").asText());
    }

    @Test void cspAllowsCognigy() throws Exception {
        String csp = mvc.perform(get("/api/chat/config")).andReturn().getResponse().getHeader("Content-Security-Policy");
        assertTrue(csp.contains("wss://*.cognigy.cloud")); assertTrue(csp.contains("https://github.com"));
    }

    @Test void keyRequired() throws Exception {
        assertEquals(401, status(get("/api/bot/plans")));
        assertEquals(401, status(get("/api/bot/plans").header("X-BOT-KEY", "wrong")));
        assertTrue(json(get("/api/bot/plans").header("X-API-Key", "test-key")).get("ok").asBoolean());      // Cognigy's built-in API-key header works too
    }

    @Test void publicPlansQuoteVerify() throws Exception {
        JsonNode p = json(key(get("/api/bot/plans?category=Cargo"))); assertTrue(p.get("ok").asBoolean()); assertTrue(p.get("count").asInt() > 0);
        JsonNode q = json(key(post("/api/bot/quote").contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(Map.of("plan_id", p.get("plans").get(0).get("id").asInt(), "sum_insured", 1000000, "year_built", 2000)))));
        assertTrue(q.get("ok").asBoolean()); assertTrue(q.get("premium").asDouble() > 0);
        assertFalse(json(key(post("/api/bot/quote").contentType(MediaType.APPLICATION_JSON).content("{\"plan_name\":\"nope\",\"sum_insured\":5}"))).get("ok").asBoolean());
        assertFalse(json(key(post("/api/bot/quote").contentType(MediaType.APPLICATION_JSON).content("{\"plan_id\":1,\"sum_insured\":-5}"))).get("ok").asBoolean());
        assertEquals("NOT_FOUND", json(key(get("/api/bot/verify/STC-NOPE"))).get("code").asText());
    }

    @Test void privateNeedsLoginAndIgnoresCookie() throws Exception {
        Login l = login("client@portal.com", "Client@123", "client");
        assertEquals("LOGIN_REQUIRED", json(key(get("/api/bot/invoices")).session(l.session())).get("code").asText());   // cookie present, no chat token -> must NOT work
        assertEquals("BAD_TOKEN", json(auth(get("/api/bot/invoices"), "junk")).get("code").asText());
    }

    @Test void scopeFollowsRoles() throws Exception {
        String client = login("client@portal.com", "Client@123", "client").token(), other = login("demo1@portal.com", "Client@123", "client").token(), admin = login("admin@portal.com", "Admin@123", "admin").token();
        assertEquals(1, json(auth(get("/api/bot/policies"), client)).get("count").asInt());
        assertEquals(0, json(auth(get("/api/bot/policies"), other)).get("count").asInt());              // another client sees nothing of Chris
        assertTrue(json(auth(get("/api/bot/policies"), admin)).get("count").asInt() >= 1);
        assertEquals(1, json(auth(get("/api/bot/invoices"), client)).get("count").asInt());
        assertEquals(0, json(auth(get("/api/bot/invoices"), other)).get("count").asInt());
        assertEquals("CLIENT_ONLY", json(auth(get("/api/bot/documents"), admin)).get("code").asText());
        assertEquals(4, json(auth(get("/api/bot/documents"), client)).get("required").size());
        assertTrue(json(auth(get("/api/bot/brokers"), client)).get("brokers").size() > 0);
    }

    @Test void certificates() throws Exception {
        String tok = login("client@portal.com", "Client@123", "client").token(), other = login("demo2@portal.com", "Client@123", "client").token();
        assertEquals(1, json(auth(get("/api/bot/certificates"), tok)).get("count").asInt());
        assertEquals("NOT_FOUND", json(auth(get("/api/bot/certificates?number=STC-000000"), tok)).get("code").asText());
        assertEquals(0, json(auth(get("/api/bot/certificates"), other)).get("count").asInt());
    }

    @Test void claimFlowAndRules() throws Exception {
        String tok = login("client@portal.com", "Client@123", "client").token(), other = login("demo3@portal.com", "Client@123", "client").token();
        String day = LocalDate.now().minusDays(5).toString();
        Map<String, Object> body = Map.of("policy_number", "MTP-2026-000001", "incident_date", day, "incident_type", "Collision", "description", "Collision with a pier while berthing", "amount_claimed", 50000);
        JsonNode r = json(post("/api/bot/claims", body, tok)); assertTrue(r.get("ok").asBoolean(), r.toString());      // no CSRF header needed on /api/bot
        String num = r.get("claim_number").asText();
        assertEquals("Submitted", json(auth(get("/api/bot/claims?number=" + num), tok)).get("claims").get(0).get("status").asText());
        assertEquals("CLAIM_REJECTED", json(post("/api/bot/claims", with(body, "amount_claimed", 999999999), tok)).get("code").asText());
        assertEquals("CLAIM_REJECTED", json(post("/api/bot/claims", with(body, "incident_date", "2999-01-01"), tok)).get("code").asText());
        assertEquals("POLICY_NOT_FOUND", json(post("/api/bot/claims", with(body, "policy_number", "MTP-NOPE"), tok)).get("code").asText());
        assertEquals("POLICY_NOT_FOUND", json(post("/api/bot/claims", body, other)).get("code").asText());          // cannot claim on someone else's policy
        assertEquals("NOT_FOUND", json(auth(get("/api/bot/claims?number=" + num), other)).get("code").asText());
    }

    static Map<String, Object> with(Map<String, Object> m, String k, Object v) { Map<String, Object> c = new java.util.HashMap<>(m); c.put(k, v); return c; }

    @Test void websiteStillNeedsCsrf() throws Exception {
        Login l = login("client@portal.com", "Client@123", "client");
        assertEquals(403, status(post("/api/claims").session(l.session()).contentType(MediaType.APPLICATION_JSON).content("{}")));
    }

    @Test void expiredToken() throws Exception {
        String tok = login("client@portal.com", "Client@123", "client").token(); long old = props.getCognigyTtl(); props.setCognigyTtl(-1);
        try { assertEquals("TOKEN_EXPIRED", json(auth(get("/api/bot/policies"), tok)).get("code").asText()); } finally { props.setCognigyTtl(old); }
    }

    @Test void handover() throws Exception {
        String msg = "I need a human for my claim please";
        assertEquals("BAD_MESSAGE", json(key(post("/api/bot/handover").contentType(MediaType.APPLICATION_JSON).content("{\"message\":\"short\"}"))).get("code").asText());
        assertEquals("BAD_EMAIL", json(key(post("/api/bot/handover").contentType(MediaType.APPLICATION_JSON).content("{\"message\":\"" + msg + "\"}"))).get("code").asText());
        assertTrue(json(key(post("/api/bot/handover").contentType(MediaType.APPLICATION_JSON).content("{\"message\":\"" + msg + "\",\"email\":\"a@b.co\"}"))).get("ok").asBoolean());
        Login admin = login("admin@portal.com", "Admin@123", "admin");
        assertTrue(json(get("/api/messages").session(admin.session())).toString().contains("Chatbot"));
    }
}
