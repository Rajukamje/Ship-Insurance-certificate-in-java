# ShipTransfer Marine Insurance Portal - Java (Spring Boot)

Java port of the Python/Flask portal. The website (HTML/CSS/JS in `src/main/resources/static`) is **unchanged**:
every `/api/...` URL, request and JSON answer is the same as in the Python version.

## Run

Needs **JDK 17+** and **Maven 3.8+** (internet once, to download the libraries).

    mvn spring-boot:run            (or ./run.sh, run.bat)      -> open http://localhost:5000
    mvn test                       chatbot API tests
    mvn package && java -jar target/portal-1.0.0.jar           production jar

Demo logins (choose the matching login type):
admin@portal.com / Admin@123 | broker@portal.com / Broker@123 (also maria@portal.com, tom@portal.com) | client@portal.com / Client@123

The insurance process, chatbot (Cognigy) and security features are described in the original README; nothing changed for users.
What to configure inside Cognigy: `COGNIGY_SETUP.md`.

## Settings (environment variables, same names as before)
`PORT` (5000) · `PORTAL_DB` (data/portal.db) · `SECRET_KEY` · `HTTPS=1` · `DEMO_MODE=0|1` · `COGNIGY_ENDPOINT_URL` · `COGNIGY_ENABLED` ·
`COGNIGY_TOKEN_TTL` · `COGNIGY_API_KEY` (else created once in `data/bot.key`) · `SMTP_HOST/PORT/USER/PASS/FROM` (real emails; otherwise only logged).
For production: set `SECRET_KEY`, `HTTPS=1`, `DEMO_MODE=0` and run behind https (nginx / load balancer).

## Python -> Java map

| Python | Java (`src/main/java/com/shiptransfer/portal`) |
|---|---|
| run.py, portal/__init__.py | `PortalApplication` (start, hourly reminder job via `@Scheduled` in `DbInit`) |
| config.py | `config/AppProps` (env vars, secret + bot key files) |
| security.py | `config/WebSecurityFilter` (CSRF, rate limit, CSP + headers), session cookie flags in `application.properties` |
| core.py | `core/Core` (login, roles, scope, quote, invoices, reminders), `core/Db` (SQL helper), `core/Row`, `core/U` |
| schema.sql, seed.py | `resources/schema.sql`, `core/DbInit` (tables + demo data) |
| pdf_service.py (reportlab) | `service/PdfService` (OpenPDF + ZXing QR, SMTP via Jakarta Mail) |
| routes/*.py | `web/*Controller` - one controller per module, same order of checks and messages |
| errors (`bad(...)`) | `core/ApiException` + `web/GlobalErrors` |
| tests/test_cognigy.py | `src/test/java/.../BotApiTest` |

## Differences to know about
* **Passwords**: hashed with BCrypt (Python used Werkzeug hashes). A Python `portal.db` can be opened (same tables), but its
  password hashes will not match - delete `data/portal.db` to get a fresh database with the demo users, or reset the passwords.
  Older databases are no longer auto-migrated (the schema already contains every column).
* **Sessions** are server-side (`JSESSIONID`, HttpOnly, SameSite=Lax, 8 h) instead of a signed cookie; the CSRF token works the same way.
* **Chat tokens** are HMAC-SHA256 signed tickets (same idea as itsdangerous); the browser just passes them to Cognigy.
* PDFs are drawn with OpenPDF; the layout follows the Python version, small pixel differences are possible.

## Folder map
    pom.xml
    src/main/java/com/shiptransfer/portal/   config/  core/  service/  web/
    src/main/resources/                      application.properties  schema.sql  static/ (website)
    src/test/java/...                        BotApiTest
    data/                                    portal.db, pdfs/, uploads/ (created automatically)
