#!/bin/sh
# Start the website:  ./run.sh   ->  http://localhost:5000
exec mvn spring-boot:run
